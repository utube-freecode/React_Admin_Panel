import { configureStore } from "@reduxjs/toolkit";
import authSlice from './slices/authSlice'
import appSlice from './slices/appSlice'


const reduxStore = configureStore({
    reducer : {
        authSlice : authSlice,
        appSlice : appSlice
    }
})


export default reduxStore
