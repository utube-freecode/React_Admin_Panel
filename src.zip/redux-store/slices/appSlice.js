import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    currentColor: localStorage.getItem('colorMode') || '#03C9D7',
    currentMode: localStorage.getItem('themeMode') || 'Dark',
    activeMenu: true,
    isClicked: {
      chat: false,
      cart: false,
      userProfile: false,
      notifications: false,
    },
    themeSettings: false,
}

const appSlice = createSlice({
    name: 'appSlice',
    initialState,
    reducers: {
        setCurrentColor: (state, action) => { 
            state.currentColor = action.payload; 
        },
        setCurrentMode: (state, action) => { 
            state.currentMode = action.payload; 
        },
        setActiveMenu: (state, action) => { 
            state.activeMenu = action.payload;
        },
        toggleClick: (state, action) => { 
            state.isClicked[action.payload] = !state.isClicked[action.payload]; 
        },
        handleClick: (state, action) => {
            const clicked = action.payload;
            state.isClicked = {
              ...state.isClicked,
              [clicked]: !state.isClicked[clicked],
            };
        },
        setThemeSettings: (state, action) => {
            state.themeSettings = action.payload;
        },
        setColor: (state, action) => {
            state.currentColor = action.payload;
            localStorage.setItem('colorMode', action.payload);
        },
        setMode: (state, action) => {
            state.currentMode = action.payload;
            localStorage.setItem("themeMode", action.payload);
        },
    }
})

export const { 
  setActiveMenu, 
  setCurrentColor, 
  setCurrentMode, 
  toggleClick, 
  handleClick, 
  setThemeSettings, 
  setColor, 
  setMode 
} = appSlice.actions

export default appSlice.reducer
