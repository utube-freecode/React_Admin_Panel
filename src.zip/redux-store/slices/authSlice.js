import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    status : false,
    userData : null
}

const authSlice = createSlice({
    name : 'authSlice',
    initialState,
    reducers : {
        loginReducer : (state, action) => {
            state.status = true,
            state.userData = action.payload
        },
        logoutReducer : (state, action) => {
            state.status = false,
            state.userData = null
        }
    }
})


export const {loginReducer, logoutReducer} = authSlice.actions

export default authSlice.reducer