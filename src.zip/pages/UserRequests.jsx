import { DropDownListComponent} from '@syncfusion/ej2-react-dropdowns'
import React, { useEffect, useState } from 'react'
import { Header } from '../components'
import axios from 'axios'
import { Card, CardContent } from '../components/Card'
import { Input } from '../components/Input'
import { Select, SelectContent, SelectItem, SelectTrigger } from '../components/Select'
import { ButtonComponent } from '../components/ButtonComponent'
import ReactPaginate from "react-paginate";
import SkeletonLoader from '../components/SkeletonLoader'
import { useQuery, useMutation, useQueryClient, useQueries } from '@tanstack/react-query';


const UserRequests = () => {
  const editing = { allowDeleting: true, allowEditing: true}

  const [isLoading, setIsLoading] = useState(false)
  //const [users, setUsers] = useState([])

  const [dropdownStr, setDropdownStr] = useState([])
  //console.log(dropdownStr, "dropdownStr")
  const [dropdownArray, setDropdownArray] = useState([])
  //console.log(dropdownArray, "dropdownArray")
  const [searchStr, setSearchStr] = useState('')
  //console.log(searchStr, "searchStr")

  const pageSize = 50; 
  //const [data, setData] = useState([]); 
  const [totalRecords, setTotalRecords] = useState(0); 
  const [totalPages, setTotalPages] = useState(0); 
  const [currentPage, setCurrentPage] = useState(1); 
  //console.log(data,  "data")
  const [backendPage, setBackendPage] = useState(1);
  //console.log(backendPage, "backendPage")
  const [backendData, setBackendData] = useState([]); 
  //console.log(backendData, "backendData")
  
    
  const [sortColumn, setSortColumn] = useState(null);  // Column to sort by
  const [sortDirection, setSortDirection] = useState('asc'); // Sort direction: 'asc' or 'desc'

  const [error, setError] = useState(null);
  //console.log(error, "error")

  const [isOpen, setIsOpen] = useState(false);

  const [searchParams, setSearchParams] = useState();
    //console.log(searchParams, "searchParams")
          
    const queryClient = useQueryClient();       // useQueryClient


  // useEffect
  // useEffect(() => {
  //       handleUsers(1)           // Calling Function
  // }, [dropdownStr])


  useEffect(() => {
    if(searchStr === ''){
      //handleUsers()           // Calling Function
      setSearchParams({
        searchStr : searchStr,
        dropdownStr : dropdownStr,
      })
    }
  },[searchStr])  



  // handleUsers
  const handleUsers = async({page = 1}) => {
    setError(null); // Clear previous errors
        try {

            //setIsLoading(true)

            const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getuserrequests`, {
              searchStr : searchStr,
              //searchSelect : searchSelect,
              dropdownStr : dropdownStr,
              page : page
            }, {
              headers : {
                "Content-Type" : "application/json"
              }
            })

            //console.log(response, "response")

            const totalRecords = response?.data?.data?.[0]?.metadata?.[0]?.total || 0;
            const totalPages = Math.ceil(totalRecords / pageSize);
            const dropdownArray  = response?.data?.whtLblUrlData || []
    
            return { data: response?.data?.data?.[0]?.data || [], totalRecords, totalPages, dropdownArray };
            //setIsLoading(false)

            
        } catch (error) {
            //console.log(error, "error")
            // setError(error?.response?.data?.message || "An error occurred while fetching data.")
            // setIsLoading(false)
            throw new Error(error?.response?.data?.message || "An error occurred while fetching data.");
        }
  }

  // useQuery
      const useUserRequest = ({ searchParams, page, pageSize }) => {
        return useQuery({
          queryKey: ['userRequest', { searchParams, page, pageSize }],
          queryFn: () => handleUsers({ page : page }),
          staleTime: 1000 * 60 * 3, // Cache data for 3 minutes before refetching
          cacheTime: 1000 * 60 * 10, // Keep cache for 10 minutes
          //enabled: !!searchParams?.fromDate && !!searchParams?.toDate, // Only fetch if dates exist
          onSuccess: (newData) => {
            const cachedData = queryClient.getQueryData(['userRequest', { searchParams, page, pageSize }]);
      
            if (JSON.stringify(newData) !== JSON.stringify(cachedData)) {
              queryClient.setQueryData(['userRequest', { searchParams, page, pageSize }], newData);
            }
      
            // Update totalRecords and totalPages globally
            setTotalRecords(newData?.totalRecords);
            setTotalPages(newData?.totalPages);
            setDropdownArray(newData?.dropdownArray);
          }
        });
      };
        
        const { data, isFetching, error : apiError } = useUserRequest({searchParams, page : currentPage});
  
        // If cached data is available, update total records immediately
        useEffect(() => {
          if (data?.totalRecords !== undefined) {
            setTotalRecords(data?.totalRecords);
            setTotalPages(data?.totalPages);
          }
          if (data?.dropdownArray !== undefined) {
            setDropdownArray(data?.dropdownArray);
          }
        }, [data]);


  const handlePageChange = (page) => {
    setCurrentPage(page);
    handleUsers(page);
  };
  

  const handleSort = (column) => {
    const direction = sortColumn === column && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortColumn(column);
    setSortDirection(direction);
  
    const sortedData = [...data]?.sort((a, b) => {
      if (column == 'balance') {
        // Explicitly parse the amount to numbers for correct numerical sorting
        const amountA = parseFloat(a[column]);
        const amountB = parseFloat(b[column]);
  
        return direction === 'asc' ? amountA - amountB : amountB - amountA;
      }
  
      if (typeof a[column] === 'string') {
        return direction === 'asc'
          ? a[column].localeCompare(b[column])
          : b[column].localeCompare(a[column]);
      } else {
        return direction === 'asc'
          ? a[column] - b[column]
          : b[column] - a[column];
      }
    });
  
    setData(sortedData);
  };

   //Handle individual selection change for request types
    const handleSelectReq = (option) => {
      setDropdownStr((prevSelected) => {
        const newSelection = prevSelected?.includes(option)
          ? prevSelected?.filter(item => item !== option)
          : [...prevSelected, option];
        return newSelection;
      });
    };
  
    //Handle "Select All" functionality
    const handleSelectAll = () => {
      setDropdownStr(dropdownStr?.length === dropdownArray?.length ? [] : dropdownArray?.map(option => option?._id) );
    };


    // handlePageClick
    const handlePageClick = (event) => {
      const selectedPage = event?.selected + 1; // Pages are zero-indexed
      setCurrentPage(selectedPage);
      handleUsers({page : selectedPage});
    };

  const DropDown = ({ currentMode }) => (
    <div className="w-72 border-1 border-color bg-white px-2 py-1 rounded-md">
       <DropDownListComponent
        id="dropdownArray"
        fields={{ text: '_id', value: '_id' }}
        placeholder="Select URLs"
        style={{
          border:'none', color: currentMode === 'Dark' && 'white'
        }}
        value={dropdownStr || "Select URLs"} 
        onChange={(e) => {
          const selectedId = e.value 
          //console.log(selectedId, "selectedId")
          if (selectedId !== "Select URLs") {
            setDisplayCount(1);
            setSelectedPage(1);
            setSelectedIndex(1);
            setDropdownStr(selectedId);
          } else {
            setDropdownStr('');
          }
        }}
        dataSource={[{_id : "Select URLs"}, ...dropdownArray]}
        popupHeight="220px"
        popupWidth="320px"
      />
    </div>
    )


  return (
    <div className='flex flex-col min-h-screen'>
  <div className='flex-grow m-2 md:m-10 mt-24 p-2 pb-4 md:p-10 bg-gray-200 md:rounded-3xl rounded-xl'>
      <Header category='' title="User Requests" />

      {/* <DropDown currentMode={"white"}/> */}

      <Card className="p-4 shadow-lg">
      <CardContent>
        <div className="flex flex-wrap items-center gap-4">

          <div className="flex items-center gap-2">
            <Input
              id="searchId"
              name="searchId"
              type="search"
              placeholder="Search..."
              value={searchStr}
              onChange={(val) => {setSearchStr(val.target.value)}}
              className="px-4 py-2 border rounded-lg"
            />
          </div>


        <div className="dropdown-container">
        {/* Dropdown */}
        <div className="dropdown">
            <button 
                className={`px-4 py-2 border rounded-lg bg-gray-100 text-left hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300 w-96`} 
                onClick={() => setIsOpen((prev) => !prev)} 
            >
                 {dropdownStr?.length === dropdownArray?.length 
                    ? "Select All" 
                    : dropdownStr?.length > 0 
                    ? dropdownArray
                        ?.filter(option => dropdownStr?.includes(option?._id))
                        ?.map(option => option?._id)
                        ?.join(", ") 
                    : "Select Filter..."}
            </button>

            {isOpen && (
            <div className={`absolute z-10 mt-2 w-96 bg-white border rounded-lg shadow-lg ${isOpen ? "block" : "hidden"}`}>
                {/* Select All Option */}
                <div className="dropdown-item">
                  <input
                      type="checkbox"
                      checked={dropdownStr?.length === dropdownArray?.length}
                      onChange={handleSelectAll}
                  />
                  <label>Select All</label>
                </div>

                <hr></hr>

                {/* Individual Options */}
                {dropdownArray?.map((option) => (
                  <div key={option?._id} className="dropdown-item">
                      <input
                        type="checkbox"
                        checked={dropdownStr?.includes(option?._id)}
                        onChange={() => {handleSelectReq(option?._id)}}
                      />
                      <label>{option?._id}</label>
                  </div>
                ))}
            </div>
            )}
        </div>
        </div>


          <style>{`
            /* Style for the dropdown container */
            .dropdown-container {
            position: relative;
            width: 200px;
            font-family: Arial, sans-serif;
            }

            /* Style for the dropdown button (trigger) */
            .dropdown-trigger {
            width: 100%;
            padding: 10px;
            background-color: #f3f4f6;
            border: 1px solid #ddd;
            text-align: left;
            cursor: pointer;
            border-radius: 8px;
            font-size: 14px;
            color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
            }

            .dropdown-trigger:hover {
            background-color: #e5e7eb;
            }

            /* Style for the dropdown content (list of checkboxes) */
            .dropdown-content {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            max-height: 200px;
            overflow-y: auto;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 10;
            padding: 10px 0;
            box-sizing: border-box;
            }

            /* Style for each item (checkbox and label) in the dropdown */
            .dropdown-item {
            padding: 8px 16px;
            display: flex;
            align-items: center;
            }

            .dropdown-item:hover {
            background-color: #f0f0f0;
            }

            /* Style for the checkboxes */
            .dropdown-item input[type="checkbox"] {
            margin-right: 10px;
            cursor: pointer;
            }

            .dropdown-item label {
            cursor: pointer;
            }

            /* Style for Select All checkbox (appears at the top) */
            .dropdown-item input[type="checkbox"]:checked + label {
            font-weight: bold;
            }
          `}</style>

          {/* Search Button */}
          <ButtonComponent 
            onClick={() => {
                if(data){
                  setIsOpen(false)
                  setCurrentPage(1)
                  setBackendPage(1)
                  setBackendData([])
                  setSortColumn(null)
                  setSortDirection('asc')
                }
                //handleUsers(1)
                setSearchParams({
                  searchStr : searchStr,
                  dropdownStr : dropdownStr,
                })
              }} 
              className="ml-auto bg-blue-500 hover:bg-blue-600 text-white"
              type="submit">
            Search
          </ButtonComponent>
        </div>
      </CardContent>
    </Card>

     {/* Table Container */}
      {!isFetching && data?.data?.length > 0 && (
        <div>
          <div className="overflow-auto max-h-[40rem] border border-gray-300 rounded-lg shadow-md relative">
            <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white">
              <thead className="top-0 bg-white text-black z-10">
                <tr>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('userName')}
                  >
                    User Name
                    {sortColumn === 'userName' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('userId')}
                  >
                    User ID
                    {sortColumn === 'userId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('whtLblUrl')}
                  >
                    URL
                    {sortColumn === 'whtLblUrl' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('token')}
                  >
                    Token
                    {sortColumn === 'token' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('balance')}
                  >
                    Balance
                    {sortColumn === 'balance' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('currency')}
                  >
                    Currency
                    {sortColumn === 'currency' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                  <th
                    className="p-2 border border-gray-300 text-left cursor-pointer"
                    onClick={() => handleSort('lastActive')}
                  >
                    Last Active
                    {sortColumn === 'lastActive' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                  </th>
                </tr>
              </thead>
              <tbody>
                {data?.data?.map((item, index) => (
                  <tr
                    key={item?._id}
                    className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}
                  >
                    <td className="p-2 border border-gray-200">{item?.userName}</td>
                    <td className="p-2 border border-gray-200">{item?.userId}</td>
                    <td className="p-2 border border-gray-200">{item?.whtLblUrl}</td>
                    <td className="p-2 border border-gray-200">{item?.token}</td>
                    <td className="p-2 border border-gray-200">{item?.balance}</td>
                    <td className="p-2 border border-gray-200">{item?.currency}</td>
                    <td className="p-2 border border-gray-200">{new Date(item?.updatedAt).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata" })}{" "}{new Date(item?.updatedAt).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour12: true })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
         
        {/* Pagination */}
        <div className="flex justify-center items-center mt-4 space-x-2">
          <ReactPaginate
              previousLabel={"Previous"}
              nextLabel={"Next"}
              breakLabel={"..."}
              pageCount={totalPages}
              marginPagesDisplayed={1}
              pageRangeDisplayed={5}
              onPageChange={handlePageClick}
              containerClassName={"flex space-x-2"}
              pageClassName={"px-3 py-2 rounded"}
              activeClassName={"text-white bg-blue-700"}
              previousClassName={"px-3 py-2 bg-blue-700 text-white rounded"}
              nextClassName={"px-3 py-2 bg-blue-700 text-white rounded"}
              disabledClassName={"opacity-50 cursor-not-allowed"}
              forcePage={currentPage - 1}
            />
          </div>


    </div>
  )}

      {/* Loader */}
      {/* {isLoading && (
        <div className="loader-overlay">  
          <div className="loader"></div>
        </div>
      )} */}
      {isFetching && (
          <div className='mt-1'>
            <SkeletonLoader type='table' columns={5} rows={8}/>
          </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="mt-4 text-red-600 text-center">{error}</div>
      )}

      {/* No Data Message */}
      {data?.data?.length === 0 && !isFetching && !error && (
        <div className="mt-4 text-gray-500 text-center">No data found for the selected search term.</div>
      )}



          {/* Styles */}
          <style>{`
            /* Full Page Loader */
            .loader-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 1000; /* High z-index to overlay on top of other content */
            }

            .loader {
              border: 5px solid #f3f3f3; /* Light gray border */
              border-top: 5px solid #3498db; /* Blue color for top border */
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite; /* Spinning animation */
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }

            /* Popup Styles */
            .popup-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5);
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 999;
            }

            .popup {
              background: #fff;
              padding: 30px;
              border-radius: 8px;
              box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
              max-width: 800px;
              width: 100%;
              overflow: hidden;
            }

            .popup h3 {
              margin-top: 0;
              margin-bottom: 20px;
            }

            .table-scroll-container {
              max-height: 300px;
              overflow-y: auto;
              border: 1px solid #ddd;
              position: relative; /* Added to allow absolute positioning for table loader */
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            th, td {
              padding: 10px;
              border: 1px solid #ddd;
              text-align: left;
            }

            th {
              background-color: #f9f9f9;
            }

            .scrollable {
              word-break: break-word;
            }

            .popup button {
              margin-top: 20px;
            }
          `}</style>
      
    </div>
  </div>
  )
}

export default UserRequests