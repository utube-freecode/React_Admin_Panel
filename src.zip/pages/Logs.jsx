
import React, { useActionState, useEffect, useRef, useState, Suspense } from 'react'
import { Header } from '../components'
import axios from 'axios'
import DatepickerComponent from '../components/DatepickerComponent'
import DynamicNavbar from '../components/DynamicNavbar'
import { Info } from "lucide-react";
import ReactPaginate from "react-paginate";
import SkeletonLoader from '../components/SkeletonLoader'
import { useQuery, useMutation, useQueryClient, useQueries } from '@tanstack/react-query';


const Logs = () => {
  const editing = { allowDeleting: true, allowEditing: true}

  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingPopup, setIsLoadingPopup] = useState(false)


  const [dropdownReq, setDropdownReq] = useState('')
  //console.log(dropdownReq, "dropdownReq")
  const [dropdownArrayReq, setDropdownArrayReq] = useState([])
  //console.log(dropdownArrayReq, "dropdownArrayReq")
  const [searchId, setSearchId] = useState('')
  //console.log(searchId, "searchId")

  const [logDetails, setLogDetails] = useState([])
  //console.log(logDetails, "logDetails")
  const [showPopup, setShowPopup] = useState(false)
  //console.log(showPopup, "showPopup")

  const [parsedReqParam, setParsedReqParam] = useState()

  const pageSize = 50; 
  //const [data, setData] = useState([]); 
  const [totalRecords, setTotalRecords] = useState(0);
  const [totalPages, setTotalPages] = useState(0); 
  const [currentPage, setCurrentPage] = useState(1); 
  //console.log(data,  "data")
  const [backendPage, setBackendPage] = useState(1);
  //console.log(backendPage, "backendPage")
  const [backendData, setBackendData] = useState([]); 
  //console.log(backendData, "backendData")

  
  const [sortColumn, setSortColumn] = useState(null);  // Column to sort by
  const [sortDirection, setSortDirection] = useState('asc'); // Sort direction: 'asc' or 'desc'
  
  const [error, setError] = useState(null);
  //console.log(error, "error")

  const today = new Date().toISOString().split("T")[0];

  const [filters, setFilters] = useState([]);
  //console.log(filters, "filters")
  const [fromDate, setFromDate] = useState(today);
  //console.log(fromDate, "fromDate")
  const [toDate, setToDate] = useState(today);
  //console.log(toDate, "toDate")
  const [searchFields, setSearchFields] = useState([])
  //console.log(searchFields, "searchFields")
  const [selectedOptionReq, setSelectedOptionReq] = useState('');
  //console.log(selectedOptionReq, "selectedOptionReq")

  const [searchParams, setSearchParams] = useState();
  //console.log(searchParams, "searchParams")
        
  const queryClient = useQueryClient();       // useQueryClient

  // const [isInitialLoad, setIsInitialLoad] = useState(true);
  // console.log(isInitialLoad, "isInitialLoad")


  useEffect(() => {
    //handleUsers({page : 1})
    setSearchParams({
      searchFields,
      fromDate,
      toDate,
      filters,
      reqType : selectedOptionReq
    })
  },[])

  //useEffect
  // useEffect(() => {
  //   if(searchId){
  //       handleUsers({page : 1})           // Calling Function
  //   }
  // }, [dropdownReq])

  useEffect(() => {
    if(logDetails){
      if(logDetails?.reqUrl === '/resultrequest'){
        setParsedReqParam(JSON.parse(logDetails?.reqParam))
      }
    }
  },[logDetails])


  // handleUsers
  const handleUsers = async({page = 1, data}) => {
      // setData([]);
      setError(null); // Clear previous errors
        try {

            //setIsLoading(true)

            const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getgenerallogs`, {
              data : {
                searchFields,
                fromDate,
                toDate,
                filters,
                reqType : selectedOptionReq
              },
              page : page,
              pageSize : pageSize
            }, {
              headers : {
                "Content-Type" : "application/json"
              }
            })

            //console.log(response, "response")
            // setTotalRecords(response?.data?.data?.[0]?.metadata?.[0]?.total);
            // setTotalPages(Math.ceil(response?.data?.data?.[0]?.metadata?.[0]?.total / 50));
            // return response?.data?.data?.[0]?.data
            const totalRecords = response?.data?.data?.[0]?.metadata?.[0]?.total || 0;
            const totalPages = Math.ceil(totalRecords / pageSize);
    
            return { data: response?.data?.data?.[0]?.data, totalRecords, totalPages };

            // setIsLoading(false)
            //setIsInitialLoad(false)
            
        } catch (error) {
            //console.log(error, "error")
            //setError(error?.response?.data?.message || "An error occurred while fetching data.")
            //setIsLoading(false)
            //setIsInitialLoad(false)
            throw new Error(error?.response?.data?.message || "An error occurred while fetching data.");
        }
  }  

    // Button click handler
    const buttonClick = async(rowData) => {
        //console.log(`Details for Log: ${rowData._id}`);
        if(rowData?._id){
          setError(null); // Clear previous errors
            try {
    
                setIsLoadingPopup(true)
    
                const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getgenerallogbyid`, {
                  _id : rowData?._id
                }, {
                  headers : {
                    "Content-Type" : "application/json"
                  }
                })
    
                //console.log(response, "response")
    
                setLogDetails(response?.data?.data)
                setIsLoadingPopup(false)
        
                //setShowDetailsButton(false)
                setShowPopup(true)
                
            } catch (error) {
                //console.log(error, "error")
                //setError('An error occurred while fetching data.');
                setError(error?.response?.data?.message || "An error occurred while fetching data.")
                setIsLoadingPopup(false)
            }
        }
    };

    // useQuery
    const useGameReport = ({ searchParams, page, pageSize }) => {
      return useQuery({
        queryKey: ['gameReport', { searchParams, page, pageSize }],
        queryFn: () => handleUsers({ page }),
        staleTime: 1000 * 60 * 3, // Cache data for 3 minutes before refetching
        cacheTime: 1000 * 60 * 10, // Keep cache for 10 minutes
        enabled: !!searchParams?.fromDate && !!searchParams?.toDate, // Only fetch if dates exist
        onSuccess: (newData) => {
          const cachedData = queryClient.getQueryData(['gameReport', { searchParams, page, pageSize }]);
    
          if (JSON.stringify(newData) !== JSON.stringify(cachedData)) {
            queryClient.setQueryData(['gameReport', { searchParams, page, pageSize }], newData);
          }
    
          // Update totalRecords and totalPages globally
          setTotalRecords(newData?.totalRecords);
          setTotalPages(newData?.totalPages);
        }
      });
    };
      
      const { data, isFetching, error : apiError } = useGameReport({searchParams, page : currentPage, pageSize});

      // If cached data is available, update total records immediately
      useEffect(() => {
        if (data?.totalRecords !== undefined) {
          setTotalRecords(data?.totalRecords);
          setTotalPages(data?.totalPages);
        }
      }, [data]);

    const handleSubmit = (data) => {
      //console.log("Data from DynamicNavbar on submit:", data);
      // setBackendPage(1)
      setCurrentPage(1)
      // setTotalRecords(0)
      // setTotalPages(0)
      //handleUsers({page : 1})
      setSearchParams({
        searchFields,
        fromDate,
        toDate,
        filters,
        reqType : selectedOptionReq
      })
    };

    const handleReset = () => {
        // setBackendPage(1)
        setCurrentPage(1)
        // setTotalRecords(0)
        // setTotalPages(0)
        // Force immediate update
        setTimeout(() => {
          //handleUsers({ page: 1 }),
          setSearchParams({
            searchFields,
            fromDate,
            toDate,
            filters,
            reqType : selectedOptionReq
          })
        }, 0);
    };
  

  const handlePageClick = (event) => {
    const selectedPage = event.selected + 1; // Pages are zero-indexed
    setCurrentPage(selectedPage);
    //handleUsers({page : selectedPage});
  };

  const handleSort = (column) => {
    const direction = sortColumn === column && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortColumn(column);
    setSortDirection(direction);
  
    const sortedData = [...data].sort((a, b) => {
      if (column == 'amount') {
        // Explicitly parse the amount to numbers for correct numerical sorting
        const amountA = parseFloat(a[column]);
        const amountB = parseFloat(b[column]);
  
        return direction === 'asc' ? amountA - amountB : amountB - amountA;
      }
  
      if (typeof a[column] === 'string') {
        return direction === 'asc'
          ? a[column].localeCompare(b[column])
          : b[column].localeCompare(a[column]);
      } else {
        return direction === 'asc'
          ? a[column] - b[column]
          : b[column] - a[column];
      }
    });
  
    setData(sortedData);
  };
  
  


  return (
    <div className='flex flex-col min-h-screen'>
      <div className='flex-grow m-2 md:m-10 mt-24 p-2 pb-4 md:p-10 bg-gray-200 md:rounded-3xl rounded-xl'>
      <Header category='' title="Game Report" />

      <DynamicNavbar 
        onFiltersChange={(filters) => setFilters(filters)}
        onSearchFieldChange={(searchFields) => setSearchFields(searchFields)}
        onDateChange={(fromDate, toDate) => {setFromDate(fromDate), setToDate(toDate)}}
        onRequestTypeChange={(selectedOptionReq) => setSelectedOptionReq(selectedOptionReq)}
        onSubmit={handleSubmit} // Pass the parent callback to handleSubmit
        onReset={handleReset}
      />
        
      {/* Table Container */}
      {!isFetching && data?.data?.length > 0 && (
        <div>
        <div className="overflow-auto max-h-[40rem] border border-gray-300 rounded-lg shadow-md">
          <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white">
            <thead className="top-0 bg-white text-black z-10">
              <tr>
              <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('userId')}
                >
                  User Name
                  {/* {sortColumn === 'userId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('userId')}
                >
                  User ID
                  {/* {sortColumn === 'userId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('amount')}
                >
                  Amount
                  {sortColumn === 'amount' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('winloss')}
                >
                  Win / Loss
                  {/* {sortColumn === 'winloss' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('round')}
                >
                  Round
                  {/* {sortColumn === 'round' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('reqUrl')}
                >
                  Req
                  {/* {sortColumn === 'reqUrl' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('reqTime')}
                >
                  Request Time
                  {sortColumn === 'reqTime' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('transactionId')}
                >
                  Transaction ID
                  {/* {sortColumn === 'transactionId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                {/* <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('category')}
                >
                  Category
                  {sortColumn === 'category' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th> */}
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('gameName')}
                >
                  Game Name
                  {/* {sortColumn === 'gameName' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                {/* <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('gameId')}
                >
                  Game ID
                  {sortColumn === 'gameId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th> */}
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('provider')}
                >
                  Provider
                  {/* {sortColumn === 'transactionId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('supplier')}
                >
                  Supplier
                  {/* {sortColumn === 'supplier' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th className="p-2 border border-gray-300 text-left">Action</th>
              </tr>
            </thead>
            <tbody>
              {data?.data?.length > 0 && (
                data?.data?.map((item, index) => {

                  let amount = '';
                  let round = '';
                  let winLoss = '';

                  if (item?.reqUrl === '/resultrequest') {
                    const param = JSON.parse(item?.reqParam);  
                    amount = param?.creditAmount; 
                    round = param?.roundId;
                    if(amount > 0){
                      winLoss = 'W'
                    }
                    else if(amount === 0){
                      winLoss = 'L'
                    }
                  } else {
                    amount = item?.amount;
                    round = item?.round;
                    winLoss = "---"
                  }

                  return (
                  <tr
                    key={item?._id}
                    className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}
                  >
                     <td className="p-2 border border-gray-200">{item?.userName}</td>
                    <td className="p-2 border border-gray-200">{item?.userId}</td>
                    {/* <td className="p-2 border border-gray-200">{amount}</td> */}
                    <td className="p-2 border border-gray-200">{item?.amount || "-----"}</td>
                    <td className="p-2 border border-gray-200"><span
                        className={`inline-block px-2 py-1 rounded 
                          ${winLoss === 'W' ? 'bg-green-700 text-white' : 
                            winLoss === 'L' ? 'bg-red-700 text-white' : 'bg-transparent text-gray-500'}`}
                      >
                        {winLoss}
                      </span>
                    </td>
                    <td className="p-2 border border-gray-200">{round}</td>
                    <td className="p-2 border border-gray-200">
                      <span
                        className={`inline-block px-2 py-1 text-white rounded 
                          ${item?.reqUrl === '/resultrequest' ? 'bg-[#566ca9]' : 
                            item?.reqUrl === '/betrequest' ? 'bg-[#aa5591]' : 'bg-gray-500'}`}
                      >
                        {item?.reqUrl === '/resultrequest' ? 'R' : 
                            item?.reqUrl === '/betrequest' ? 'B' : 'O' }
                      </span>
                    </td>
                    <td className="p-2 border border-gray-200">{new Date(item?.reqTime).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata" })}{" "}{new Date(item?.reqTime).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour12: true })}</td>
                    <td className="p-2 border border-gray-200">{item?.transactionId}</td>
                    {/* <td className="p-2 border border-gray-200">{item?.category || '-----'}</td> */}
                    <td className="p-2 border border-gray-200">{item?.game_name || '-----'}</td>
                    {/* <td className="p-2 border border-gray-200">{item?.game_id || '-----'}</td> */}
                    <td className="p-2 border border-gray-200">{item?.provider_name || '-----'}</td>
                    <td className="p-2 border border-gray-200">{item?.sub_provider_name || '-----'}</td>
                    <td className=" border border-gray-300">
                      <button
                        onClick={() => buttonClick(item)}
                        className="px-2 py-1 text-gray-600 rounded"
                      >
                        <Info color='gray' />Info
                      </button>
                    </td>
                  </tr>
                )})
              )}
            </tbody>
          </table>
        </div>

     {/* Pagination */}
     <div className="flex justify-center items-center mt-4 space-x-2">
      <ReactPaginate
          previousLabel={"Previous"}
          nextLabel={"Next"}
          breakLabel={"..."}
          pageCount={totalPages}
          marginPagesDisplayed={1}
          pageRangeDisplayed={5}
          onPageChange={handlePageClick}
          containerClassName={"flex space-x-2"}
          pageClassName={"px-3 py-2 rounded"}
          activeClassName={"text-white bg-blue-700"}
          previousClassName={"px-3 py-2 bg-blue-700 text-white rounded"}
          nextClassName={"px-3 py-2 bg-blue-700 text-white rounded"}
          disabledClassName={"opacity-50 cursor-not-allowed"}
          forcePage={currentPage - 1}
        />
      </div>

    </div>
  )}
      

        {/* Loader */}
        {isLoadingPopup && !isFetching && (
          <div className="loader-overlay">
            <div className="loader"></div>
          </div>
        )}
        {isFetching && !isLoadingPopup && (
          <div className='mt-1'>
            <SkeletonLoader type='table' columns={5} rows={8}/>
          </div>
      )}

        {/* {isInitialLoad && (
          <div className="mt-4 text-gray-500 text-center">Try searching user id, amount, round and transaction id to get started</div>
        )} */}

        {/* Error Message */}
        {error && (
          <div className="mt-4 text-red-600 text-center">{error}</div>
        )}

        {/* No Data Message */}
        {data?.length === 0 && !isLoading && !error  && (
          <div className="mt-4 text-gray-500 text-center">No data found for the selected search term.</div>
        )}

          {/* Popup Component */}
          {showPopup && (
            <div className="popup-overlay">
              <div className="popup">
                <h3>Log Details</h3>
                {logDetails && (
                  <div className="table-scroll-container">
                    <table>
                      <thead>
                        <tr>
                          <th>Field</th>
                          <th>Value</th>
                        </tr>
                      </thead>
                      <tbody>
                      <tr>
                          <td>User Name</td>
                          <td>{logDetails?.userName}</td>
                        </tr>
                        <tr>
                          <td>User ID</td>
                          <td>{logDetails?.userId}</td>
                        </tr>
                        <tr>
                          <td>Round</td>
                          <td>{logDetails?.reqUrl === '/resultrequest' ?  parsedReqParam?.roundId || '-----' : logDetails?.round}</td>
                        </tr>
                        {/* <tr>
                          <td>Amount</td>
                          <td>{logDetails?.reqUrl === '/resultrequest' ?  parsedReqParam?.creditAmount?.toString() || '-' : logDetails?.amount}</td>
                        </tr> */}
                        <tr>
                          <td>Amount</td>
                          <td>{logDetails?.amount || "-"}</td>
                        </tr>
                        {logDetails?.reqUrl === '/resultrequest' && (
                          <tr>
                          <td>Win / Loss</td>
                            <td>
                              <span 
                                  className={`inline-block px-2 py-1 text-white rounded 
                                    ${parsedReqParam?.creditAmount === 0 ? 'bg-red-700' : 
                                      parsedReqParam?.creditAmount > 0 ? 'bg-green-700' : 'bg-gray-500'}`}
                                >
                                  {parsedReqParam?.creditAmount === 0 ? 'Loss' : 'Win' || '-'}
                              </span>
                            </td>
                        </tr>
                        )}
                        
                        {logDetails?.category && (
                          <tr>
                            <td>Category</td>
                            <td>{logDetails?.category || '-'}</td>
                          </tr>
                        )}
                        {logDetails?.game_name && (
                          <tr>
                            <td>Game Name</td>
                            <td>{logDetails?.game_name || '-'}</td>
                          </tr>
                        )}
                        {logDetails?.game_id && (
                          <tr>
                            <td>Game ID</td>
                            <td>{logDetails?.game_id || '-'}</td>
                          </tr>
                        )}
                        {logDetails?.provider_name && (
                         <tr>
                          <td>Provider</td>
                          <td>{logDetails?.provider_name || '-'}</td>
                        </tr>
                        )}
                        {logDetails?.sub_provider_name && (
                           <tr>
                            <td>Supplier</td>
                            <td>{logDetails?.sub_provider_name || '-'}</td>
                          </tr>
                        )}
                        <tr>
                          <td>Transaction ID</td>
                          <td>{logDetails?.transactionId}</td>
                        </tr>
                        <tr>
                          <td>Proceed Status</td>
                          <td>{logDetails?.proceedStatus}</td>
                        </tr>
                        <tr>
                          <td>Request Method</td>
                          <td>{logDetails?.reqMethod}</td>
                        </tr>
                        <tr>
                          <td>Request Name</td>
                          <td>{logDetails.reqName}</td>
                        </tr>
                        <tr>
                          <td>Request URL</td>
                          <td className="scrollable"> 
                            <span 
                              className={`inline-block px-2 py-1 text-white rounded 
                                ${logDetails?.reqUrl === '/resultrequest' ? 'bg-[#566ca9]' : 
                                  logDetails?.reqUrl === '/betrequest' ? 'bg-[#aa5591]' : 'bg-gray-500'}`}
                            >
                              {logDetails?.reqUrl}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td>Request UUID</td>
                          <td>{logDetails?.request_uuid || '-'}</td>
                        </tr>
                        <tr>
                          <td>Request Time</td>
                          <td>{new Date(logDetails?.reqTime).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata" })}{" "}
                          {new Date(logDetails?.reqTime).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour12: true })}</td>
                        </tr>
                        <tr>
                          <td>Request Param</td>
                          <td className="scrollable">{logDetails?.reqParam}</td>
                        </tr>
                        <tr>
                          <td>Response</td>
                          <td className="scrollable">{logDetails?.response || '-'}</td>
                        </tr>
                        <tr>
                          <td>Response Time</td>
                          <td>{logDetails?.resTime && new Date(logDetails?.resTime).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata" })}{" "}
                          {logDetails?.resTime && new Date(logDetails?.resTime).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour12: true})}
                          {!logDetails?.resTime && "-"}</td>
                        </tr>
                        <tr>
                          <td>Created At</td>
                          <td>{new Date(logDetails?.createdAt).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata" })}{" "}
                          {new Date(logDetails?.createdAt).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour12: true })}</td>
                        </tr>
                        <tr>
                          <td>Updated At</td>
                          <td>{new Date(logDetails?.updatedAt).toLocaleDateString("en-GB", { timeZone: "Asia/Kolkata" })}{" "}
                          {new Date(logDetails?.updatedAt).toLocaleTimeString("en-GB", { timeZone: "Asia/Kolkata", hour12: true })}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}
                <button
                  className="e-btn e-flat e-primary"
                  onClick={() => {setShowPopup(false)}}
                >
                  Close
                </button>
              </div>
            </div>
          )}

          {/* Styles */}
          <style>{`
            /* Full Page Loader */
            .loader-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 1000; /* High z-index to overlay on top of other content */
            }

            .loader {
              border: 5px solid #f3f3f3; /* Light gray border */
              border-top: 5px solid #3498db; /* Blue color for top border */
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite; /* Spinning animation */
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }

            /* Table Loader (Inside Table) */
            .table-loader-overlay {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(255, 255, 255, 0.7); /* Semi-transparent white */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 500; /* Lower z-index than full page loader */
            }

            /* Popup Styles */
            .popup-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5);
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 999;
            }

            .popup {
              background: #fff;
              padding: 30px;
              border-radius: 8px;
              box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
              max-width: 800px;
              width: 100%;
              overflow: hidden;
            }

            .popup h3 {
              margin-top: 0;
              margin-bottom: 20px;
            }

            .table-scroll-container {
              max-height: 300px;
              overflow-y: auto;
              border: 1px solid #ddd;
              position: relative; /* Added to allow absolute positioning for table loader */
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            th, td {
              padding: 10px;
              border: 1px solid #ddd;
              text-align: left;
            }

            th {
              background-color: #f9f9f9;
            }

            .scrollable {
              word-break: break-word;
            }

            .popup button {
              margin-top: 20px;
            }
          `}</style>

        

      {/* {data.length > 0 && searchId && (
        <div style={{display : 'flex', flexDirection : 'row', width : '100%', }}>
        <div style={{display : 'flex', flexDirection : 'row', justifyContent : 'flex-start'}}>
          <p>{totalDocs?.total || 0} Documents</p>
        </div>

        <div className="grid shrink-0 grid-cols-1 focus-within:relative">
          <select
            id="SetOfDocuments"
            name="SetOfDocuments"
            aria-label="SetOfDocuments"
            value={selectedIndex !== null ? selectedIndex : "placeholder"}
            onChange={(e) => {
              const index = parseInt(e.target.value, 10); // Convert value to number
              setSelectedIndex(index);
              setSelectedPage(index + 1)
              setDisplayCount(`Set ${index * 50 + 1} to ${index * 50 + 50}`); 
            }}
            className="col-start-1 row-start-1 w-full appearance-none rounded-md py-1.5 pl-3 pr-7 text-base text-gray-500 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-blue-500 sm:text-sm/6"
          >
            <option value="placeholder" disabled>
              Set of Documents
            </option>

            {Array.from({ length: page }, (_, index) => (
              <option key={index} value={index}>
                Set {index * 50 + 1} to {index * 50 + 50}
              </option>
            ))}
          </select>
        </div>
        </div>
      )}*/}
      
    </div>
  </div>
  )
}

export default Logs