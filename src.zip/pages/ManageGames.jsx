
import React, { useActionState, useEffect, useRef, useState, Suspense } from 'react'
import { Header } from '../components'
import axios from 'axios'
import DatepickerComponent from '../components/DatepickerComponent'
import DynamicNavbar from '../components/DynamicNavbar'
import { Info } from "lucide-react";
import ReactPaginate from "react-paginate";
import SkeletonLoader from '../components/SkeletonLoader'
import { useQuery, useMutation, useQueryClient, useQueries } from '@tanstack/react-query';
import DynamicNavbarAnalysisNew from '../components/DynamicNavbarAnalysisNew'
import TableRow from '../components/TableRow'
import DynamicNavbarManageGames from '../components/DynamicNavbarManageGames'


const ManageGames = () => {
  const editing = { allowDeleting: true, allowEditing: true}

  const [isLoading, setIsLoading] = useState(false)
 

  const pageSize = 50; 
  //const [data, setData] = useState([]); 
  const [totalRecords, setTotalRecords] = useState(0);
  const [totalPages, setTotalPages] = useState(0); 
  const [currentPage, setCurrentPage] = useState(1); 
  //console.log(data,  "data")
  const [backendPage, setBackendPage] = useState(1);
  //console.log(backendPage, "backendPage")
  const [backendData, setBackendData] = useState([]); 
  //console.log(backendData, "backendData")

  
  const [sortColumn, setSortColumn] = useState(null);  // Column to sort by
  const [sortDirection, setSortDirection] = useState('asc'); // Sort direction: 'asc' or 'desc'
  
  const [error, setError] = useState(null);
  //console.log(error, "error")

  const today = new Date().toISOString().split("T")[0];

  const [filters, setFilters] = useState([]);
  //console.log(filters, "filters")
  const [searchFields, setSearchFields] = useState([])
  //console.log(searchFields, "searchFields")
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('');
  //console.log(selectedStatusFilter, "selectedStatusFilter")

  const [searchParams, setSearchParams] = useState();
  //console.log(searchParams, "searchParams")
        
  const queryClient = useQueryClient();       // useQueryClient

  // const [isInitialLoad, setIsInitialLoad] = useState(true);
  // console.log(isInitialLoad, "isInitialLoad")


  useEffect(() => {
    //handleUsers({page : 1})
    setSearchParams({
      searchFields,
      filters,
      statusFilter : selectedStatusFilter
    })
  },[])




  // handleUsers
  const handleUsers = async({page = 1, data}) => {
      // setData([]);
      setError(null); // Clear previous errors
        try {

            //setIsLoading(true)

            const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getactivegames`, {
              data : {
                searchFields,
                filters,
                statusFilter : selectedStatusFilter
              },
              page : page,
              pageSize : pageSize
            }, {
              headers : {
                "Content-Type" : "application/json"
              }
            })

            //console.log(response, "response")
            // setTotalRecords(response?.data?.data?.[0]?.metadata?.[0]?.total);
            // setTotalPages(Math.ceil(response?.data?.data?.[0]?.metadata?.[0]?.total / 50));
            // return response?.data?.data?.[0]?.data
            const totalRecords = response?.data?.data?.[0]?.metadata?.[0]?.total || 0;
            const totalPages = Math.ceil(totalRecords / pageSize);
    
            return { data: response?.data?.data?.[0]?.data, totalRecords, totalPages };

            // setIsLoading(false)
            //setIsInitialLoad(false)
            
        } catch (error) {
            //console.log(error, "error")
            //setError(error?.response?.data?.message || "An error occurred while fetching data.")
            //setIsLoading(false)
            //setIsInitialLoad(false)
            throw new Error(error?.response?.data?.message || "An error occurred while fetching data.");
        }
  }  


    // useQuery
    const useActiveGames = ({ searchParams, page, pageSize }) => {
      return useQuery({
        queryKey: ['activeGames', { searchParams, page, pageSize }],
        queryFn: () => handleUsers({ page }),
        staleTime: 1000 * 60 * 1, // Cache data for 1 minutes before refetching
        cacheTime: 1000 * 60 * 2, // Keep cache for 2 minutes
        onSuccess: (newData) => {
          const cachedData = queryClient.getQueryData(['activeGames', { searchParams, page, pageSize }]);
    
          if (JSON.stringify(newData) !== JSON.stringify(cachedData)) {
            queryClient.setQueryData(['activeGames', { searchParams, page, pageSize }], newData);
          }
    
          // Update totalRecords and totalPages globally
          setTotalRecords(newData?.totalRecords);
          setTotalPages(newData?.totalPages);
        }
      });
    };
      
      const { data, isFetching, error : apiError } = useActiveGames({searchParams, page : currentPage, pageSize});

      // If cached data is available, update total records immediately
      useEffect(() => {
        if (data?.totalRecords !== undefined) {
          setTotalRecords(data?.totalRecords);
          setTotalPages(data?.totalPages);
        }
      }, [data]);

    const handleSubmit = (data) => {
      //console.log("Data from DynamicNavbar on submit:", data);
      // setBackendPage(1)
      setCurrentPage(1)
      // setTotalRecords(0)
      // setTotalPages(0)
      //handleUsers({page : 1})
      setSearchParams({
        searchFields,
        filters,
        statusFilter : selectedStatusFilter
      })
    };

    const handleReset = () => {
        // setBackendPage(1)
        setCurrentPage(1)
        // setTotalRecords(0)
        // setTotalPages(0)
        // Force immediate update
        setTimeout(() => {
          //handleUsers({ page: 1 }),
          setSearchParams({
            searchFields,
            filters,
            statusFilter : selectedStatusFilter
          })
        }, 0);
    };
  

  const handlePageClick = (event) => {
    const selectedPage = event.selected + 1; // Pages are zero-indexed
    setCurrentPage(selectedPage);
    //handleUsers({page : selectedPage});
  };

  const handleSort = (column) => {
    const direction = sortColumn === column && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortColumn(column);
    setSortDirection(direction);
  
    const sortedData = [...data].sort((a, b) => {
      if (column == 'amount') {
        // Explicitly parse the amount to numbers for correct numerical sorting
        const amountA = parseFloat(a[column]);
        const amountB = parseFloat(b[column]);
  
        return direction === 'asc' ? amountA - amountB : amountB - amountA;
      }
  
      if (typeof a[column] === 'string') {
        return direction === 'asc'
          ? a[column].localeCompare(b[column])
          : b[column].localeCompare(a[column]);
      } else {
        return direction === 'asc'
          ? a[column] - b[column]
          : b[column] - a[column];
      }
    });
  
    setData(sortedData);
  };
  
  


  return (
    <div className='flex flex-col min-h-screen'>
      <div className='flex-grow m-2 md:m-10 mt-24 p-2 pb-4 md:p-10 bg-gray-200 md:rounded-3xl rounded-xl'>
      <Header category='' title="Manage Games" />

      <DynamicNavbarManageGames  
        onFiltersChange={(filters) => setFilters(filters)}
        onSearchFieldChange={(searchFields) => setSearchFields(searchFields)}
        onStatusTypeChange={(value) => setSelectedStatusFilter(value)}
        onSubmit={handleSubmit} // Pass the parent callback to handleSubmit
        onReset={handleReset}
      />
        
      {/* Table Container */}
      {!isFetching && data?.data?.length > 0 && (
        <div>
        <div className="overflow-auto max-h-[40rem] border border-gray-300 rounded-lg shadow-md">
          <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white">
            <thead className="top-0 bg-white text-black z-10">
              <tr>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                //   onClick={() => handleSort('gameId')}
                >
                  Game ID
                  {/* {sortColumn === 'gameId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                //   onClick={() => handleSort('category')}
                >
                  Category
                  {/* {sortColumn === 'category' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('gameName')}
                >
                  Game Name
                  {/* {sortColumn === 'gameName' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('provider')}
                >
                  Provider
                  {/* {sortColumn === 'transactionId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('supplier')}
                >
                  Supplier
                  {/* {sortColumn === 'supplier' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('supplier')}
                >
                  Game Code
                  {/* {sortColumn === 'supplier' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('supplier')}
                >
                  Casino Type
                  {/* {sortColumn === 'supplier' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('supplier')}
                >
                  Currency
                  {/* {sortColumn === 'supplier' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th className="border border-gray-300 text-left">Active Status</th>
              </tr>
            </thead>
            <tbody>
              {data?.data?.length > 0 && (
                data?.data?.map((item, index) => {
                  return (
                    <TableRow key={index} id={item?._id} item={item} initialStatus={item?.status} index={index}/>
                )})
              )}
            </tbody>
          </table>
        </div>

     {/* Pagination */}
     <div className="flex justify-center items-center mt-2 space-x-2">
      <ReactPaginate
          previousLabel={"Previous"}
          nextLabel={"Next"}
          breakLabel={"..."}
          pageCount={totalPages}
          marginPagesDisplayed={1}
          pageRangeDisplayed={5}
          onPageChange={handlePageClick}
          containerClassName={"flex space-x-2"}
          pageClassName={"px-3 py-2 rounded"}
          activeClassName={"text-white bg-blue-700"}
          previousClassName={"px-3 py-2 bg-blue-700 text-white rounded"}
          nextClassName={"px-3 py-2 bg-blue-700 text-white rounded"}
          disabledClassName={"opacity-50 cursor-not-allowed"}
          forcePage={currentPage - 1}
        />
      </div>

    </div>
  )}
      

        {isFetching && (
          <div className='mt-1'>
            <SkeletonLoader type='table' columns={5} rows={8}/>
          </div>
        )}

        {/* {isInitialLoad && (
          <div className="mt-4 text-gray-500 text-center">Try searching user id, amount, round and transaction id to get started</div>
        )} */}

        {/* Error Message */}
        {error && (
          <div className="mt-4 text-red-600 text-center">{error}</div>
        )}

        {/* No Data Message */}
        {data?.data?.length === 0 && !isLoading && !error  && (
          <div className="mt-4 text-gray-500 text-center">No data found for the selected search term.</div>
        )}


          {/* Styles */}
          <style>{`
            /* Full Page Loader */
            .loader-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 1000; /* High z-index to overlay on top of other content */
            }

            .loader {
              border: 5px solid #f3f3f3; /* Light gray border */
              border-top: 5px solid #3498db; /* Blue color for top border */
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite; /* Spinning animation */
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }

            /* Table Loader (Inside Table) */
            .table-loader-overlay {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(255, 255, 255, 0.7); /* Semi-transparent white */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 500; /* Lower z-index than full page loader */
            }


            .table-scroll-container {
              max-height: 300px;
              overflow-y: auto;
              border: 1px solid #ddd;
              position: relative; /* Added to allow absolute positioning for table loader */
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            th, td {
              padding: 10px;
              border: 1px solid #ddd;
              text-align: left;
            }

            th {
              background-color: #f9f9f9;
            }

            .scrollable {
              word-break: break-word;
            }

          `}</style>

        

      {/* {data.length > 0 && searchId && (
        <div style={{display : 'flex', flexDirection : 'row', width : '100%', }}>
        <div style={{display : 'flex', flexDirection : 'row', justifyContent : 'flex-start'}}>
          <p>{totalDocs?.total || 0} Documents</p>
        </div>

        <div className="grid shrink-0 grid-cols-1 focus-within:relative">
          <select
            id="SetOfDocuments"
            name="SetOfDocuments"
            aria-label="SetOfDocuments"
            value={selectedIndex !== null ? selectedIndex : "placeholder"}
            onChange={(e) => {
              const index = parseInt(e.target.value, 10); // Convert value to number
              setSelectedIndex(index);
              setSelectedPage(index + 1)
              setDisplayCount(`Set ${index * 50 + 1} to ${index * 50 + 50}`); 
            }}
            className="col-start-1 row-start-1 w-full appearance-none rounded-md py-1.5 pl-3 pr-7 text-base text-gray-500 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-blue-500 sm:text-sm/6"
          >
            <option value="placeholder" disabled>
              Set of Documents
            </option>

            {Array.from({ length: page }, (_, index) => (
              <option key={index} value={index}>
                Set {index * 50 + 1} to {index * 50 + 50}
              </option>
            ))}
          </select>
        </div>
        </div>
      )}*/}
      
    </div>
  </div>
  )
}

export default ManageGames