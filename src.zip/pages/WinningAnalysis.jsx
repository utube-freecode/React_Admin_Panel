import React, { useActionState, useEffect, useRef, useState, Suspense } from 'react'
import { Header } from '../components'
import axios from 'axios'
import DatepickerComponent from '../components/DatepickerComponent'
import DynamicNavbar from '../components/DynamicNavbar'
import ReactPaginate from "react-paginate";
import SpendingTable from '../components/SpendingTable'
import DynamicNavbarAnalysisNew from '../components/DynamicNavbarAnalysisNew'
import SpendingTableAnalysis from '../components/SpendingTableAnalysis'
import WinTableAnalysis from '../components/WinTableAnalysis'
import WinTable from '../components/WinTable'
import SkeletonLoader from '../components/SkeletonLoader'
import { useQuery, useMutation, useQueryClient, useQueries } from '@tanstack/react-query';

const SpendingChart = React.lazy(() => import('../components/SpendingChart'));
const SingleDaySpendingChart = React.lazy(() => import('../components/SingleDaySpendingChart'))


const WinningAnalysis = () => {
  const editing = { allowDeleting: true, allowEditing: true}

  const [isLoading, setIsLoading] = useState(false)

  //const [data, setData] = useState([]); 
  //console.log(data, "dataa")
  //const [dataProviders, setDataProviders] = useState([]); 
  //console.log(dataProviders, "dataProviders")
  //const [dataTotalAnalysis, setDataTotalAnalysis] = useState(); 
  //console.log(dataTotalAnalysis, "dataTotalAnalysis")
  
  //const [error, setError] = useState(null);
  //console.log(error, "error")

  const today = new Date().toISOString().split("T")[0];

  const [filters, setFilters] = useState([]);
  //console.log(filters, "filters")
  const [fromDate, setFromDate] = useState(today);
  //console.log(fromDate, "fromDate")
  const [toDate, setToDate] = useState(today);
  //console.log(toDate, "toDate")
  const [searchFields, setSearchFields] = useState([])
  //console.log(searchFields, "searchFields")
  const [selectedOptionReq, setSelectedOptionReq] = useState('');
  //console.log(selectedOptionReq, "selectedOptionReq")

  const [searchParams, setSearchParams] = useState();
  //console.log(searchParams, "searchParams")
  
  const queryClient = useQueryClient();       // useQueryClient


  useEffect(() => {
    //handleAnalysisByGames()
    //handleAnalysisByProviders()
    //handleAnalysisTotal()
    setSearchParams({
      searchFields,
      fromDate,
      toDate,
      filters,
    })
  },[])



  // handleAnalysisByGames
  const handleAnalysisByGames = async() => {
        try {
            const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getwinanalysisbygames`, {
              data : {
                searchFields,
                fromDate,
                toDate,
                filters,
                
              },
            }, {
              headers : {
                "Content-Type" : "application/json"
              }
            })

            //console.log(response, "response")
            return response?.data?.data || []
            
        } catch (error) {
          throw new Error(error?.response?.data?.message || "An error occurred while fetching data.");
        }
  }

  // handleAnalysisByProviders
  const handleAnalysisByProviders = async() => {
      try {
          const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getwinanalysisbyproviders`, {
            data : {
              searchFields,
              fromDate,
              toDate,
              filters,
            },
          }, {
            headers : {
              "Content-Type" : "application/json"
            }
          })

          //console.log(response, "response")
          return response?.data?.data || []
          
      } catch (error) {
        throw new Error(error?.response?.data?.message || "An error occurred while fetching data.");
      }
    }  

    const results = useQueries({
        queries: [
          {
            queryKey: ['winningAnalysisByProviders', searchParams],
            queryFn: () => handleAnalysisByProviders(),
            staleTime: 1000 * 60 * 3, // Cached for 3 minutes
            cacheTime: 1000 * 60 * 10, // Keep cache for 10 minutes
            enabled: !!searchParams?.fromDate && !!searchParams?.toDate,
            onSuccess: (newData) => {
              const cachedData = queryClient.getQueryData(['winningAnalysisByProviders', searchParams]);
              if (JSON.stringify(newData) !== JSON.stringify(cachedData)) {
                queryClient.setQueryData(['winningAnalysisByProviders', searchParams], newData);
              }
            },
          },
          {
            queryKey: ['winningAnalysisByGames', searchParams],
            queryFn: () => handleAnalysisByGames(),
            staleTime: 1000 * 60 * 3, // Cached for 3 minutes
            cacheTime: 1000 * 60 * 10, // Keep cache for 10 minutes
            enabled: !!searchParams?.fromDate && !!searchParams?.toDate,
            onSuccess: (newData) => {
              const cachedData = queryClient.getQueryData(['winningAnalysisByGames', searchParams]);
              if (JSON.stringify(newData) !== JSON.stringify(cachedData)) {
                queryClient.setQueryData(['winningAnalysisByGames', searchParams], newData);
              }
            },
          },
        ],
      });
      
      // Extract results
      const dataProviders = results[0]?.data;
      const isFetchingProviders = results[0]?.isFetching;
      //const isFetching = results.some(result => result?.isFetching);
      const error = results?.find(result => result?.error)?.error;
      const data = results[1]?.data;
      const isFetchingGames = results[1]?.isFetching;



    const handleSubmit = (data) => {
      //console.log("Data from DynamicNavbar on submit:", data);
      //handleAnalysisByGames()
      //handleAnalysisByProviders()
      // handleAnalysisTotal()
      setSearchParams({
        searchFields,
        fromDate,
        toDate,
        filters,
      })
    };

    const handleReset = () => {
        // Force immediate update
        setTimeout(() => {
          // handleAnalysisByGames(), 
          // handleAnalysisByProviders(),
          setSearchParams({
            searchFields,
            fromDate,
            toDate,
            filters,
          })
        }, 0);
    };
  

  return (
    <div className='flex flex-col min-h-screen'>
      <div className='flex-grow m-2 md:m-10 mt-24 p-2 pb-4 md:p-10 bg-gray-200 md:rounded-3xl rounded-xl'>
      <Header category='' title="Winning Analysis" />

      <DynamicNavbarAnalysisNew 
        onFiltersChange={(filters) => setFilters(filters)}
        onSearchFieldChange={(searchFields) => setSearchFields(searchFields)}
        onDateChange={(fromDate, toDate) => {setFromDate(fromDate), setToDate(toDate)}}
        onRequestTypeChange={(selectedOptionReq) => setSelectedOptionReq(selectedOptionReq)}
        onSubmit={handleSubmit} // Pass the parent callback to handleSubmit
        onReset={handleReset}
      />
    
        {/* Loader */}
        {/* {isLoading && (
          <div className="loader-overlay">
            <div className="loader"></div>
          </div>
        )} */}
        {isFetchingProviders && (
          <div className='mt-4'>
              <SkeletonLoader type="content" contentBlocks={1} />
          </div>
        )}
        {isFetchingGames && (
            <div className='mt-4'>
                <SkeletonLoader type='table' columns={5} rows={3}/>
            </div>
        )}

  

        {/* Error Message */}
        {error && (
          <div className="mt-4 text-red-600 text-center">{error}</div>
        )}

        {/* No Data Message */}
        {data?.length === 0 && dataProviders?.length === 0 && !isFetchingGames && !isFetchingProviders && !error  && (
          <div className="mt-4 text-gray-500 text-center">No data found for the selected search term.</div>
        )}

        {!isFetchingProviders && dataProviders?.length > 0 && (
          <WinTableAnalysis data={dataProviders}/>
        )}

        {!isFetchingGames && data?.length > 0 &&  (
          <WinTable data={data}/>
        )}  


          {/* Styles */}
          <style>{`
            /* Full Page Loader */
            .loader-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 1000; /* High z-index to overlay on top of other content */
            }

            .loader {
              border: 5px solid #f3f3f3; /* Light gray border */
              border-top: 5px solid #3498db; /* Blue color for top border */
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite; /* Spinning animation */
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }

            /* Table Loader (Inside Table) */
            .table-loader-overlay {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(255, 255, 255, 0.7); /* Semi-transparent white */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 500; /* Lower z-index than full page loader */
            }

            /* Popup Styles */
            .popup-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5);
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 999;
            }

            .popup {
              background: #fff;
              padding: 30px;
              border-radius: 8px;
              box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
              max-width: 800px;
              width: 100%;
              overflow: hidden;
            }

            .popup h3 {
              margin-top: 0;
              margin-bottom: 20px;
            }

            .table-scroll-container {
              max-height: 300px;
              overflow-y: auto;
              border: 1px solid #ddd;
              position: relative; /* Added to allow absolute positioning for table loader */
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            th, td {
              padding: 10px;
              border: 1px solid #ddd;
              text-align: left;
            }

            th {
              background-color: #f9f9f9;
            }

            .scrollable {
              word-break: break-word;
            }

            .popup button {
              margin-top: 20px;
            }
          `}</style>

      
    </div>
  </div>
  )
}

export default WinningAnalysis