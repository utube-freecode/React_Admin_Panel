
import React, { useActionState, useEffect, useRef, useState, Suspense } from 'react'
import { Header } from '../components'
import axios from 'axios'
import DatepickerComponent from '../components/DatepickerComponent'
import DynamicNavbar from '../components/DynamicNavbar'
import ReactPaginate from "react-paginate";
import DynamicNavbarAnalysis from '../components/DynamicNavbarAnalysis'
import SkeletonLoader from '../components/SkeletonLoader'
import { useQuery, useMutation, useQueryClient, useQueries } from '@tanstack/react-query';


const VisualAnalysis = () => {
  const editing = { allowDeleting: true, allowEditing: true}

  const [isLoading, setIsLoading] = useState(false)
  

  const [dropdownReq, setDropdownReq] = useState('')
  //console.log(dropdownReq, "dropdownReq")
  const [dropdownArrayReq, setDropdownArrayReq] = useState([])
  //console.log(dropdownArrayReq, "dropdownArrayReq")
  const [searchId, setSearchId] = useState('')
  //console.log(searchId, "searchId")

  const [parsedReqParam, setParsedReqParam] = useState()

  const pageSize = 50; 
  //const [data, setData] = useState([]); 
  //console.log(data, "data")
  const [totalRecords, setTotalRecords] = useState(0);
  const [totalPages, setTotalPages] = useState(0); 
  const [currentPage, setCurrentPage] = useState(1); 
  //console.log(data,  "data")
  const [backendPage, setBackendPage] = useState(1);
  //console.log(backendPage, "backendPage")
  const [backendData, setBackendData] = useState([]); 
  //console.log(backendData, "backendData")

  
  const [sortColumn, setSortColumn] = useState(null);  // Column to sort by
  const [sortDirection, setSortDirection] = useState('asc'); // Sort direction: 'asc' or 'desc'
  
  const [error, setError] = useState(null);
  //console.log(error, "error")

  const today = new Date().toISOString().split("T")[0];

  const [filters, setFilters] = useState([]);
  //console.log(filters, "filters")
  const [fromDate, setFromDate] = useState(today);
  //console.log(fromDate, "fromDate")
  const [toDate, setToDate] = useState(today);
  //console.log(toDate, "toDate")
  const [searchFields, setSearchFields] = useState([])
  //console.log(searchFields, "searchFields")
  
  const [searchStr, setSearchStr] = useState('')

  const [searchParams, setSearchParams] = useState();
  //console.log(searchParams, "searchParams")
      
  const queryClient = useQueryClient();       // useQueryClient

  // useEffect(() => {
  //   if(logDetails){
  //     if(logDetails?.reqUrl === '/resultrequest'){
  //       setParsedReqParam(JSON.parse(logDetails?.reqParam))
  //     }
  //   }
  // },[logDetails])


  // handleUsers
  const handleUsers = async({page, data}) => {
    if(searchStr){
        // setData([]);
        setError(null); // Clear previous errors
        try {

            setIsLoading(true)

            const response = await axios.post(`${process.env.REACT_APP_API_URL}/panel/getgenerallogvisualanalysisamount`, {
              data : {
                searchFields,
                fromDate,
                toDate,
                filters,
                userId : searchStr
              },
              page : page,
              pageSize : pageSize
            }, {
              headers : {
                "Content-Type" : "application/json"
              }
            })

            //console.log(response, "response")

            return response?.data?.data || []
            //setIsLoading(false)
            
        } catch (error) {
            //console.log(error, "error")
            //setError(error?.response?.data?.message || "An error occurred while fetching data.")
            //setIsLoading(false)
            throw new Error(error?.response?.data?.message || "An error occurred while fetching data.");
        }
    }
    else{
      setError('User id or user name is required')
    }
  }  

  // useQuery
     const useVisualAnalysis = (searchParams) => {
      return useQuery({
          queryKey: ['visualAnalysis', searchParams],
          queryFn: () => handleUsers({page : 1}),
          staleTime: 1000 * 60 * 3, // Use cached data for 3 minutes before fetching new
          cacheTime: 1000 * 60 * 10, // Keep cache for 10 minutes
          enabled:!!searchParams?.userId && !!searchParams?.fromDate && !!searchParams?.toDate, // Prevent fetching if dates are missing
          onSuccess: (newData) => {
            const cachedData = queryClient.getQueryData(['visualAnalysis', searchParams]);
            if (JSON.stringify(newData) !== JSON.stringify(cachedData)) {
              queryClient.setQueryData(['visualAnalysis', searchParams], newData);
            }
          }
      });
    };
  
    const { data, isFetching, error : apiError } = useVisualAnalysis(searchParams);
  

   

    const handleSubmit = (data) => {
      //console.log("Data from DynamicNavbar on submit:", data);
      setBackendPage(1)
      setCurrentPage(1)
      setTotalRecords(0)
      setTotalPages(0)
      //handleUsers({page : 1})
      if(searchStr){
        setSearchParams({
          searchFields,
          fromDate,
          toDate,
          filters,
          userId : searchStr
        })
      }
      else{
        setError('User id or user name is required')
      }
    };

    const handleReset = () => {
        setBackendPage(1)
        setCurrentPage(1)
        setTotalRecords(0)
        setTotalPages(0)
        //setData([])
        //setError('')
        // Force immediate update
        if(searchStr){
          setTimeout(() => {
            //handleUsers({ page: 1 }),
            setSearchParams({
              searchFields,
              fromDate,
              toDate,
              filters,
              userId : searchStr
            })
          }, 0);
        }
        else{
          setError('User id or user name is required')
        }
    };


  const handlePageClick = (event) => {
    const selectedPage = event.selected + 1; // Pages are zero-indexed
    setCurrentPage(selectedPage);
    handleUsers({page : selectedPage});
  };

  const handleSort = (column) => {
    const direction = sortColumn === column && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortColumn(column);
    setSortDirection(direction);
  
    const sortedData = [...data].sort((a, b) => {
      if (column == 'Total Bet Amount') {
        // Explicitly parse the amount to numbers for correct numerical sorting
        const amountA = parseFloat(a[column]);
        const amountB = parseFloat(b[column]);
  
        return direction === 'asc' ? amountA - amountB : amountB - amountA;
      }
  
      if (typeof a[column] === 'string') {
        return direction === 'asc'
          ? a[column].localeCompare(b[column])
          : b[column].localeCompare(a[column]);
      } else {
        return direction === 'asc'
          ? a[column] - b[column]
          : b[column] - a[column];
      }
    });
  
    // Update the sumData inside the data object after sorting
    setData(sortedData);
  };
  

  return (
    <div className='flex flex-col min-h-screen'>
      <div className='flex-grow m-2 md:m-10 mt-24 p-2 pb-4 md:p-10 bg-gray-200 md:rounded-3xl rounded-xl'>
      <Header category='' title="Visual Analysis" />

      <DynamicNavbarAnalysis 
        onFiltersChange={(filters) => setFilters(filters)}
        onSearchFieldChange={(searchFields) => setSearchFields(searchFields)}
        onDateChange={(fromDate, toDate) => {setFromDate(fromDate), setToDate(toDate)}}
        onSearchStrChange={(value) => setSearchStr(value)}
        onSubmit={handleSubmit} // Pass the parent callback to handleSubmit
        onReset={handleReset}
      />

      {/* Loader */}
      {/* {isLoading && (
        <div className="loader-overlay">
          <div className="loader"></div>
        </div>
      )} */}
      {isFetching && (
          <div className='mt-1'>
            <SkeletonLoader type='table' columns={5} rows={8}/>
          </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="mt-4 text-red-600 text-center">{error}</div>
      )}
      {apiError && (
        <div className="mt-4 text-red-600 text-center">{apiError}</div>
      )}

      {/* No Data Message */}
      {data?.length === 0 && !isFetching && !error  && (
        <div className="mt-4 text-gray-500 text-center">No data found for the selected search term.</div>
      )}

        
      {/* Table Container */}
      {!isFetching && data?.length > 0 && (
        <div>
        <div className="overflow-auto max-h-[40rem] border border-gray-300 rounded-lg shadow-md">
          <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white">
            <thead className="top-0 bg-white text-black z-10">
              <tr>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  //onClick={() => handleSort('userId')}
                >
                  User Name
                  {/* {sortColumn === 'User ID' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  //onClick={() => handleSort('userId')}
                >
                  User ID
                  {/* {sortColumn === 'User ID' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('totalAmount')}
                >
                  Total Bet Amount
                  {sortColumn === 'totalAmount' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('totalAmount')}
                >
                  Won / Loss Amount
                  {/* {sortColumn === 'totalAmount' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('totalAmount')}
                >
                  Rollback Amount
                  {/* {sortColumn === 'totalAmount' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                {/* <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('winloss')}
                >
                  Win / Loss
                  {sortColumn === 'winloss' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th> */}
                {/* <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('transactionId')}
                >
                  Transaction ID
                  {sortColumn === 'transactionId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th> */}
                {/* <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('category')}
                >
                  Category
                  {sortColumn === 'category' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th> */}
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('Game Name')}
                >
                  Game Name
                  {/* {sortColumn === 'Game Name' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                {/* <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  onClick={() => handleSort('gameId')}
                >
                  Game ID
                  {sortColumn === 'gameId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
                </th> */}
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  //onClick={() => handleSort('Provider')}
                >
                  Provider
                  {/* {sortColumn === 'transactionId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
                <th
                  className="p-2 border border-gray-300 text-left cursor-pointer"
                  // onClick={() => handleSort('supplier')}
                >
                  Supplier
                  {/* {sortColumn === 'supplier' && (sortDirection === 'asc' ? ' ↑' : ' ↓')} */}
                </th>
              </tr>
            </thead>
            <tbody>
              {data?.length > 0 && (
                data?.map((item, index) => {

                  let betAmount = "-----";
                  let amount = '-----';
                  let rollbackAmount ="-----";
                  let winLoss = 'O';

                  // Find the reqUrl of interest
                  const resultReqUrl = item?.reqUrls?.find(url => url?.reqUrl === "/resultrequest");
                  if (resultReqUrl) {
                    amount = resultReqUrl?.amount?.toFixed(2);
                  }

                  // Find the reqUrl of interest
                  const betReqUrl = item?.reqUrls?.find(url => url?.reqUrl === "/betrequest");
                  if (betReqUrl) {
                    betAmount = betReqUrl?.amount?.toFixed(2);
                  }

                  // Find the reqUrl of interest
                  const rollBackReqUrl = item?.reqUrls?.find(url => url?.reqUrl === "/rollbackrequest");
                  if (rollBackReqUrl) {
                    rollbackAmount = rollBackReqUrl?.amount?.toFixed(2);
                  }

                  // Determine win/loss
                  if (amount > 0) {
                    winLoss = 'W';
                  } else if (amount <= 0) {
                    winLoss = 'L';
                  }

                  return (
                  <tr
                    key={index}
                    className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}
                  >
                    <td className="p-2 border border-gray-200">{item?._id?.userName || "-----"}</td>
                    <td className="p-2 border border-gray-200">{item?._id?.userId}</td>
                    <td className="p-2 border border-gray-200">{betAmount}</td>
                    <td className="p-2 border border-gray-200">
                      <span
                        className={`inline-block px-2 py-1 rounded 
                          ${winLoss === 'W' ? 'bg-green-700 text-white' : 
                            winLoss === 'L' ? 'bg-red-700 text-white' : 'bg-transparent text-gray-500'}`}
                      >
                        {amount}
                      </span>
                    </td>
                    <td className="p-2 border border-gray-200">{rollbackAmount}</td>
                    {/* <td className="p-2 border border-gray-200"><span
                        className={`inline-block px-2 py-1 rounded 
                          ${winLoss === 'W' ? 'bg-green-700 text-white' : 
                            winLoss === 'L' ? 'bg-red-700 text-white' : 'bg-transparent text-gray-500'}`}
                      >
                        {winLoss}
                      </span>
                    </td> */}
                    {/* <td className="p-2 border border-gray-200">{item?.category || '-----'}</td> */}
                    <td className="p-2 border border-gray-200">{item?._id?.game_name || '-----'}</td>
                    {/* <td className="p-2 border border-gray-200">{item?.game_id || '-----'}</td> */}
                    <td className="p-2 border border-gray-200">{item?._id?.provider_name || '-----'}</td>
                    <td className="p-2 border border-gray-200">{item?._id?.sub_provider_name || '-----'}</td>
                  </tr>
                )})
              )}
            </tbody>
          </table>
        </div>


    </div>
  )}
      


          {/* Styles */}
          <style>{`
            /* Full Page Loader */
            .loader-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 1000; /* High z-index to overlay on top of other content */
            }

            .loader {
              border: 5px solid #f3f3f3; /* Light gray border */
              border-top: 5px solid #3498db; /* Blue color for top border */
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite; /* Spinning animation */
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }

            /* Table Loader (Inside Table) */
            .table-loader-overlay {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(255, 255, 255, 0.7); /* Semi-transparent white */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 500; /* Lower z-index than full page loader */
            }

            /* Popup Styles */
            .popup-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5);
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 999;
            }

            .popup {
              background: #fff;
              padding: 30px;
              border-radius: 8px;
              box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
              max-width: 800px;
              width: 100%;
              overflow: hidden;
            }

            .popup h3 {
              margin-top: 0;
              margin-bottom: 20px;
            }

            .table-scroll-container {
              max-height: 300px;
              overflow-y: auto;
              border: 1px solid #ddd;
              position: relative; /* Added to allow absolute positioning for table loader */
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            th, td {
              padding: 10px;
              border: 1px solid #ddd;
              text-align: left;
            }

            th {
              background-color: #f9f9f9;
            }

            .scrollable {
              word-break: break-word;
            }

            .popup button {
              margin-top: 20px;
            }
          `}</style>
      
    </div>
  </div>
  )
}

export default VisualAnalysis