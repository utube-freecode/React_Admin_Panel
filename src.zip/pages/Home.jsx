import { useSelector } from "react-redux";



function Home(){

  const authStatus = useSelector(state => state?.authSlice)
  //console.log(authStatus, "authStatusRedux")

    return (
      <div className='flex flex-col items-center min-h-screen'>
  
        <h1 className="text text-white mt-16">Welcome Back</h1>
  
      </div>
    );
}

export default Home