import ReactDOM from 'react-dom'
import './index.css'
import './App.css'
import { App } from './App'
import { ContextProvider } from './contexts/ContextProvider'
import { Provider, useDispatch } from 'react-redux';
import reduxStore from './redux-store/reduxStore'

ReactDOM.render( 
    <Provider store={reduxStore}>
        <App/>
    </Provider>, document.getElementById('root')
)