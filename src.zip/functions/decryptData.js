import CryptoJS from "crypto-js";

function decryptData(cipherText, secretKey) {
    try {
        // Decrypt the ciphertext
        const bytes = CryptoJS.AES.decrypt(cipherText, 'nothing');
        const plainText = bytes.toString(CryptoJS.enc.Utf8);

        if (!plainText) throw new Error("Decryption returned empty string");

        // Parse back to JSON if applicable
        return JSON.parse(plainText);
    } catch (error) {
        console.error("Decryption Error:", error.message);
        throw new Error("Decryption failed");
    }
}

export default decryptData


// Decrypt function
// const decryptData = (encryptedPayload) => {
//     try {
//       const key = CryptoJS.enc.Utf8.parse("nothing"); // Secret key
//       const hashedKey = CryptoJS.SHA256(key)
//   ; // Hash the key for AES-256 compatibility
  
//       // Split the payload into IV and ciphertext
//       const parts = encryptedPayload.split(":");
//       if (parts.length !== 2) {
//         throw new Error("Invalid encrypted payload format");
//       }
//       const iv = CryptoJS.enc.Base64.parse(parts[0]); // Extract IV
//       const ciphertext = CryptoJS.enc.Base64.parse(parts[1]); // Extract ciphertext
  
//       // Decrypt using AES-256-CBC
//       const decrypted = CryptoJS.AES.decrypt(
//         { ciphertext: ciphertext },
//         hashedKey,
//         {
//           iv: iv,
//           mode: CryptoJS.mode.CBC,
//           padding: CryptoJS.pad.Pkcs7,
//         }
//       );
  
//       const plaintext = decrypted.toString(CryptoJS.enc.Utf8);
//       return JSON.parse(plaintext); // Parse the decrypted JSON
//     } catch (error) {
//       console.error("Decryption failed:", error);
//       throw new Error("Failed to decrypt the API response");
//     }
//   };


// export default decryptData