import React, { createContext, useContext, useState } from 'react';
import encryptData from '../functions/encryptData';
import { useDispatch } from 'react-redux';
import { loginReducer, logoutReducer } from '../redux-store/slices/authSlice';


const AuthContext = createContext();


export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); 
  const [redirectTo, setRedirectTo] = useState(null); // To store the route to redirect after login

  const dispatch = useDispatch()

  const login = () => {
    setIsAuthenticated(true)
    try {
      const cipherData = encryptData(JSON.stringify({'status'  : 'admin'}))
      //console.log(cipherData, "cipherData")
      localStorage.setItem('loginStatus', cipherData)
      dispatch(loginReducer(cipherData))
    } catch (error) {
      //console.log(error)
    }
  };
  const logout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem('loginStatus')
    dispatch(logoutReducer())
  };

  const setRedirectPath = (path) => {
    setRedirectTo(path); // Store the route to redirect to after login
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout, setRedirectPath, redirectTo}}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use AuthContext
export const useAuth = () => useContext(AuthContext);
