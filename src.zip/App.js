

import React, { useEffect} from 'react'
import { Footer, Navbar, Sidebar, ThemeSettings } from './components'
import { BrowserRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom'
import { FiSettings } from 'react-icons/fi'
import { TooltipComponent } from '@syncfusion/ej2-react-popups'
import { useStateContext } from './contexts/ContextProvider'
import { Ecommerce, Orders, Employees, Customers, Calendar, Kanban, Editor, ColorPicker, Line, Pie, StackedChart, Area, Bar, ColorMapping, Financial, Pyramid, WinningAnalysis, VisualAnalysis, UserAnalysis, ManageGames } from './pages'
import UserRequests from './pages/UserRequests'
import Home from './pages/Home'
import { AuthProvider, useAuth } from './auth/AuthProvider'
import Login from './pages/Login'
import ProtectedRoute from './auth/ProtectedRoute'
import Logs from './pages/Logs'
import decryptData from './functions/decryptData'
import Analysis from './pages/Analysis'
import { Provider, shallowEqual, useDispatch, useSelector } from 'react-redux';
import reduxStore from './redux-store/reduxStore'
import { setActiveMenu, toggleClick, handleClick, setCurrentColor, setCurrentMode, setThemeSettings } from './redux-store/slices/appSlice'
import HamburgerMenu from './components/HamburgerMenu'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'



export const App = () => {
  //const { currentColor, setCurrentColor, currentMode, setCurrentMode, activeMenu, themeSettings, setThemeSettings } = useStateContext()

  const dispatch = useDispatch();
  const { currentColor, activeMenu, currentMode,themeSettings } = useSelector((state) => state.appSlice, shallowEqual);
  
  // Create a QueryClient instance
  const queryClient = new QueryClient();
  
  // useEffect(() => {
  //   const currentThemeColor = localStorage.getItem('colorMode') || currentColor;
  //   const currentThemeMode = localStorage.getItem('themeMode') || currentMode;
  
  //   if (currentThemeColor && currentThemeMode) {
  //     dispatch(setCurrentColor(currentThemeColor));
  //     dispatch(setCurrentMode(currentThemeMode));
  //   }
  // }, [dispatch, currentColor, currentMode]);


  const Layout = ({children}) => {
    const location = useLocation();
    const isLoginPage = location.pathname === '/' || location.pathname === '/login';

    return (
      <div className={currentMode === 'Dark' ? 'dark' : ''}>
        <div className="flex relative dark:bg-main-dark-bg">
          {!isLoginPage && (
            <div className="fixed right-4 bottom-4" style={{ zIndex:'' }}>
            <TooltipComponent
            content='Settings'
            position='Top'
            >
              <button
              type='button'
              onClick={() => dispatch(setThemeSettings(true))}
              style={{ backgroundColor:currentColor, borderRadius:'50%'}}
              className='text-3xl text-white p-3 drop-shadow-xl hover:bg-light-gray'
              >
                <FiSettings/>
              </button>
            </TooltipComponent>
          </div>
          )}
          {/* Render sidebar only if not on login page */}
          {!isLoginPage && (
            <>
              {activeMenu ? (
                <div className="w-72 fixed sidebar dark:bg-secondary-dark-bg bg-white z-10">
                  <Sidebar />
                </div>
              ) : (
                <div className="w-0 dark:bg-secondary-dark-bg">
                  <Sidebar />
                </div>
              )}
            </>
          )}

          <div
            className={
              activeMenu
                ? 'dark:bg-main-dark-bg bg-main-bg min-h-screen md:ml-72 w-full'
                : 'bg-main-bg dark:bg-main-dark-bg w-full min-h-screen flex-2'
            }
          >
            {/* Render Navbar only if not on login page */}
            {!isLoginPage && (
              <div className="fixed md:static bg-main-bg dark:bg-main-dark-bg navbar w-full">
                <Navbar />
              </div>
            )}

            {/* Render ThemeSettings if enabled */}
            {themeSettings && <ThemeSettings />}

            {/* Render the main content */}
            {children}

            {/* Render Footer only if not on login page */}
            {!isLoginPage && <Footer />}
          </div>
        </div>
      </div>
    );
  };


  return (
      <AuthProvider>
         <QueryClientProvider client={queryClient}>
          <BrowserRouter>
            {/* <Layout> */}
              <HamburgerMenu >
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Login />} />
                <Route path="/login" element={<Login />} />

                {/* Protected Routes */}
                <Route path="/ecommerce" element={<ProtectedRoute><Ecommerce /></ProtectedRoute>} />
                {/* <Route path="/orders" element={<Orders />} /> */}
                <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
                <Route path="/userrequests" element={<ProtectedRoute><UserRequests /></ProtectedRoute>} />
                <Route path="/game-report" element={<ProtectedRoute><Logs /></ProtectedRoute>} />
                <Route path="/analysis" element={<ProtectedRoute><Analysis /></ProtectedRoute>} />
                <Route path="/visual-analysis" element={<ProtectedRoute><VisualAnalysis /></ProtectedRoute>} />
                <Route path="/winning-analysis" element={<ProtectedRoute><WinningAnalysis /></ProtectedRoute>} />
                <Route path="/user-analysis" element={<ProtectedRoute><UserAnalysis /></ProtectedRoute>} />
                <Route path="/manage-games" element={<ProtectedRoute><ManageGames /></ProtectedRoute>} />
                {/* <Route path="/employees" element={<Employees />} />
                <Route path="/customers" element={<Customers />} /> */}

                {/* App Routes */}
                {/* <Route path="/calendar" element={<ProtectedRoute><Calendar /></ProtectedRoute>} />
                <Route path="/kanban" element={<ProtectedRoute><Kanban /></ProtectedRoute>} />
                <Route path="/editor" element={<ProtectedRoute><Editor /></ProtectedRoute>} />
                <Route path="/color-picker" element={<ProtectedRoute><ColorPicker /></ProtectedRoute>} /> */}

                {/* Charts */}
                {/* <Route path="/line" element={<ProtectedRoute><Line /></ProtectedRoute>} />
                <Route path="/pie" element={<ProtectedRoute><Pie /></ProtectedRoute>} />
                <Route path="/stacked" element={<ProtectedRoute><StackedChart /></ProtectedRoute>} />
                <Route path="/area" element={<ProtectedRoute><Area /></ProtectedRoute>} />
                <Route path="/bar" element={<ProtectedRoute><Bar /></ProtectedRoute>} />
                <Route path="/color-mapping" element={<ProtectedRoute><ColorMapping /></ProtectedRoute>} />
                <Route path="/financial" element={<ProtectedRoute><Financial /></ProtectedRoute>} />
                <Route path="/pyramid" element={<ProtectedRoute><Pyramid /></ProtectedRoute>} /> */}
              </Routes>
              </HamburgerMenu>
            {/* </Layout> */}
          </BrowserRouter>
          <ReactQueryDevtools initialIsOpen={false} />
          </QueryClientProvider>
      </AuthProvider>
  )
}
