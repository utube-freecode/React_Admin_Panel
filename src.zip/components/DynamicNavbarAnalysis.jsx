import React, { useEffect, useState } from "react";
import { Card, CardContent } from "./Card";
import { ButtonComponent } from "./ButtonComponent";
import { Select, SelectTrigger, SelectContent, SelectItem } from "./Select";
import { Input } from "./Input";
import { CalendarIcon, ChevronDown, PlusCircleIcon, XCircleIcon } from "lucide-react";
import gameListLive from '../json/gameListLive.json'

const DynamicNavbarAnalysis = ({ 
  onFiltersChange, 
  onSearchFieldChange, 
  onDateChange, 
  onSearchStrChange,
  onSubmit,
  onReset
}) => {
  const today = new Date().toISOString().split("T")[0];

  const [filters, setFilters] = useState([]);
  const [fromDate, setFromDate] = useState(today);
  const [toDate, setToDate] = useState(today);
  const [selectedOption, setSelectedOption] = useState();
  const [isOpen, setIsOpen] = useState(false);

  const options = ["Provider", "Supplier", "Game Name", "Game ID", "Category"];

  const [openDropdowns, setOpenDropdowns] = useState({});
  //console.log(openDropdowns, "openDropdowns")
  const [searchQueries, setSearchQueries] = useState({}); // Store search query for each dropdown
  //console.log(searchQueries, "searchQueries")

  const [searchFields, setSearchFields] = useState([]);

  const [searchStr, setSearchStr] = useState('')

  const [uniqueCategories, setUniqueCategories] = useState([])
  //console.log(uniqueCategories, "uniqueCategories")
  const [uniqueGameId, setUniqueGameId] = useState([])
  //console.log(uniqueGameId, "uniqueGameId")
  const [uniqueGameName, setUniqueGameName] = useState([])
  //console.log(uniqueGameName, "uniqueGameName")
  const [uniqueProvider, setUniqueProvider] = useState([])
  //console.log(uniqueProvider, "uniqueProvider")
  const [uniqueSupplier, setUniqueSupplier] = useState([])
  //console.log(uniqueSupplier, "uniqueSupplier")

  const [reset, setReset] = useState(false)
  //console.log(reset, "reset")

  // toggleDropdown
  const toggleDropdown = (filter) => {
    setOpenDropdowns((prev) => {
      const isCurrentlyOpen = prev[filter];
      return {
        ...prev,
        [filter]: !isCurrentlyOpen, // Toggle dropdown
      };
    });
    // Clear search query when closing the dropdown
    if (openDropdowns[filter]) {
      setSearchQueries((prev) => ({
        ...prev,
        [filter]: "", // Reset search query when dropdown closes
      }));
    }
  };


  // handleSearchChange
  const handleSearchChange = (filter, query) => {
    setSearchQueries((prev) => ({
      ...prev,
      [filter]: query, // Update search query for the specific dropdown
    }));
  };


  //Define options for dropdown-based filters
  const dropdownOptions = {
    Category: uniqueCategories,
    Provider: uniqueProvider,
    Supplier: uniqueSupplier,
    "Game Name": uniqueGameName,
    "Game ID": uniqueGameId
  };


  // useEffect
 useEffect(() => {
    const CategoriesJson = [...new Set(gameListLive?.map(item => item?.category))]
    setUniqueCategories(CategoriesJson || [])

    const GameIdJson = [...new Set(gameListLive?.map(item => item?.game_id))]
    setUniqueGameId(GameIdJson || [])

    const GameNameJson = [...new Set(gameListLive?.map(item => item?.game_name))]
    setUniqueGameName(GameNameJson || [])

    const ProviderJson = [...new Set(gameListLive?.map(item => item?.provider_name))]
    setUniqueProvider(ProviderJson || [])

    const SupplierJson = [...new Set(gameListLive?.map(item => item?.sub_provider_name))]
    setUniqueSupplier(SupplierJson || [])
 },[])


  useEffect(() => {
      onFiltersChange(filters);
  }, [filters]);
  
  useEffect(() => {
      onSearchFieldChange(searchFields);
  }, [searchFields]);
  
  useEffect(() => {
    if (fromDate && toDate) {
      onDateChange(fromDate, toDate);
    }
  }, [fromDate, toDate]);
  
  useEffect(() => {
    onSearchStrChange(searchStr);
  }, [searchStr]);
  

  useEffect(() => {
    if (reset && filters.length === 0 && searchFields.length === 0) {
      onReset(); 
      setReset(false);
    }
  }, [reset, filters, searchFields]);
  

  // Update individual search field values
  const updateSearchField = (field, value) => {
    setSearchFields((prev) => {
      const updatedSearchFields = { ...prev, [field]: value };
      return updatedSearchFields;
    });
  };

  // Remove a search field by name
  const removeSearchField = (field) => {
    setSearchFields((prev) => {
      const newSearchFields = { ...prev };
      delete newSearchFields[field];
      return newSearchFields;
    });
  };

  const handleSelect = (option) => {
    setSelectedOption(option);
    addFilter(option);
    setIsOpen(false); // Close dropdown after selection
  };


  // addFilter
  const addFilter = (filter) => {
    if (!filters.includes(filter)) {
      setFilters((prevFilters) => {
        const updatedFilters = [...prevFilters, filter];
        return updatedFilters;
      });
    }
  };

  // removeFilter
  const removeFilter = (filter) => {
    setFilters((prevFilters) => {
      const updatedFilters = prevFilters.filter(f => f !== filter);
      return updatedFilters;
    });
  };

  // Handle date changes with validation
  const handleDateChange = (field, value) => {
    if (field === "fromDate") {
      const maxToDate = new Date(value);
      maxToDate.setMonth(maxToDate.getMonth() + 3);
      if (new Date(toDate) > maxToDate) {
        setFromDate(value);
        setToDate(maxToDate.toISOString().split("T")[0]);
      } else {
        setFromDate(value);
      }
    } else if (field === "toDate") {
      const maxFromDate = new Date(value);
      maxFromDate.setMonth(maxFromDate.getMonth() - 1);
      if (new Date(fromDate) < maxFromDate) {
        setFromDate(maxFromDate.toISOString().split("T")[0]);
        setToDate(value);
      } else {
        setToDate(value);
      }
    }
  };

  // handleSubmit
  const handleSubmit = () => {
    setIsOpen(false)
    const formData = {
      searchFields,
      fromDate,
      toDate,
      filters,
      searchStr
    };
    //console.log("Submitted", formData);
    onSubmit(formData); // Pass data to parent on submit
  }

  // Reset function
  const handleReset = () => {
      setIsOpen(false)
      setFilters([]); 
      setSearchFields([]); 
      setOpenDropdowns({}); 
      setSearchQueries({}); 
      setSelectedOption(""); 
      //setSearchStr('')
      //setReset(true)
      setTimeout(() => setReset(true), 0);
  }

return (
  <Card className="p-4 shadow-lg">
    <CardContent>
      <div className="flex flex-wrap items-center gap-4">

        <div className="flex items-center gap-2">
          <Input
            id="searchId"
            name="searchId"
            type="search"
            placeholder="Search User..."
            value={searchStr}
            onChange={(val) => {setSearchStr(val.target.value)}}
            className="px-4 py-2 border rounded-lg"
          />
        </div>

        {/* Date Range Selectors */}
        <div className="flex items-center gap-2">
          <label className="font-medium">From:</label>
          <Input
              type="date"
              value={fromDate}
              max={toDate} // `toDate` sets the upper limit for `fromDate`
              onChange={(e) => handleDateChange("fromDate", e.target.value)}
              className="px-4 py-2 border rounded-lg"
          />
          <CalendarIcon className="text-gray-500" />
        </div>

        <div className="flex items-center gap-2">
          <label className="font-medium">To:</label>
          <Input
            type="date"
            value={toDate}
            min={fromDate}
            max={new Date(new Date(fromDate).setMonth(new Date(fromDate).getMonth() + 3)).toISOString().split("T")[0]}
            onChange={(e) => handleDateChange("toDate", e.target.value)}
            className="w-40"
          />
          <CalendarIcon className="text-gray-500" />
        </div>



        {/* Filter Dropdown */}
        <Select onClick={() => setIsOpen(false)}  className="w-64">
          <SelectTrigger
              value={selectedOption}
              placeholder="Select Filter..."
              onClick={() => setIsOpen((prev) => !prev)} // Toggle dropdown visibility
          />
          <SelectContent isOpen={isOpen}>
              {options.map((option, index) => (
              <SelectItem key={index} value={option} onSelect={handleSelect} />
              ))}
          </SelectContent>
      </Select>

    

        {/* Dynamic Filter Fields */}
        <div className="flex flex-wrap items-center gap-2">
          {filters?.map((filter) => (
            <div
              key={filter}
              className="flex items-center gap-2 border rounded-lg p-2 bg-gray-100"
            >
             {/* Check if the filter requires a dropdown */}
              {dropdownOptions[filter] ? (
                <Select onClick={() => toggleDropdown(filter)} className="w-64">
                  <SelectTrigger
                    value={searchFields[filter]}
                    placeholder={`Select ${filter}`}
                    onClick={() => toggleDropdown(filter)}
                  />
                  {openDropdowns[filter] && (
                    <SelectContent 
                      isOpen={openDropdowns[filter]}
                      className="max-h-60 overflow-y-auto bg-white border border-gray-300 shadow-lg p-2 rounded-md">
                      {/* Search Input inside Dropdown */}
                      <div className="p-2">
                        <Input
                          type="text"
                          placeholder="Search..."
                          value={searchQueries[filter] || ""}
                          onChange={(e) => handleSearchChange(filter, e.target.value)}
                          className="w-full p-2 border border-gray-300 rounded-md"
                        />
                      </div>

                      {/* Filtered Dropdown Items */}
                      {dropdownOptions[filter]
                        .filter((option) => option.toLowerCase().includes((searchQueries[filter] || "").toLowerCase()))
                        .map((option, index) => (
                          <SelectItem
                            key={index}
                            value={option}
                            onSelect={() => {
                              updateSearchField(filter, option);
                              toggleDropdown(filter); // Close dropdown after selection
                            }}
                            className="p-2 hover:bg-gray-100 cursor-pointer"
                          >
                            {option}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  )}
                </Select>
              ) : (
                <Input
                  type="text"
                  placeholder={`Search by ${filter}`}
                  value={searchFields[filter] || ""}
                  onChange={(e) => updateSearchField(filter, e.target.value)}
                  className="w-40"
                />
              )}

              <XCircleIcon
                className="text-red-500 cursor-pointer"
                onClick={() => {
                  removeFilter(filter);
                  removeSearchField(filter);
                }}
              />
            </div>
          ))}
        </div>

        <style>{`
          /* Style for the dropdown container */
          .dropdown-container {
          position: relative;
          width: 200px;
          font-family: Arial, sans-serif;
          }

          /* Style for the dropdown button (trigger) */
          .dropdown-trigger {
          width: 100%;
          padding: 10px;
          background-color: #f3f4f6;
          border: 1px solid #ddd;
          text-align: left;
          cursor: pointer;
          border-radius: 8px;
          font-size: 14px;
          color: #333;
          display: flex;
          justify-content: space-between;
          align-items: center;
          }

          .dropdown-trigger:hover {
          background-color: #e5e7eb;
          }

          /* Style for the dropdown content (list of checkboxes) */
          .dropdown-content {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          max-height: 200px;
          overflow-y: auto;
          background-color: white;
          border: 1px solid #ddd;
          border-radius: 4px;
          box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
          z-index: 10;
          padding: 10px 0;
          box-sizing: border-box;
          }

          /* Style for each item (checkbox and label) in the dropdown */
          .dropdown-item {
          padding: 8px 16px;
          display: flex;
          align-items: center;
          }

          .dropdown-item:hover {
          background-color: #f0f0f0;
          }

          /* Style for the checkboxes */
          .dropdown-item input[type="checkbox"] {
          margin-right: 10px;
          cursor: pointer;
          }

          .dropdown-item label {
          cursor: pointer;
          }

          /* Style for Select All checkbox (appears at the top) */
          .dropdown-item input[type="checkbox"]:checked + label {
          font-weight: bold;
          }
        `}</style>

        {/* Search & Reset Buttons */}
        <div className="flex gap-2">
          <ButtonComponent 
            onClick={handleSubmit} 
            className="bg-blue-500 hover:bg-blue-600 text-white">
            Search
          </ButtonComponent>

          <ButtonComponent 
            onClick={handleReset} 
            className="bg-red-600 hover:bg-red-700 text-white">
            Reset
          </ButtonComponent>
        </div>


      </div>
    </CardContent>
  </Card>
);
};

export default DynamicNavbarAnalysis;
