// SpendingChart.js
import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2'; // Import the Bar chart from react-chartjs-2
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js'; // Import necessary components from Chart.js
import 'tailwindcss/tailwind.css'; // Ensure Tailwind is properly imported

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const SpendingChart = ({props}) => {
  const [data, setData] = useState({
    labels: [],
    datasets: [
      {
        label: 'Total Spend',
        data: [],
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  });

  // Mock data for total spends per day (In a real-world app, you would fetch this from an API)
  const spendingData = [
    { date: new Date('2025-01-19T00:00:00.000Z'), amount: 120 },
    { date: new Date('2025-01-20T00:00:00.000Z'), amount: 150 },
    { date: new Date('2025-01-03'), amount: 180 },
    { date: new Date('2025-01-04'), amount: 100 },
    { date: new Date('2025-01-05'), amount: 200 },
    { date: new Date('2025-01-06'), amount: 50 },
    { date: new Date('2025-01-07'), amount: 90 },
  ];

//   useEffect(() => {
//     const labels = spendingData.map((entry) => entry.date);
//     const values = spendingData.map((entry) => entry.amount);

//     setData({
//       labels: labels,
//       datasets: [
//         {
//           label: 'Total Spend',
//           data: values,
//           backgroundColor: 'rgba(75, 192, 192, 0.2)',
//           borderColor: 'rgba(75, 192, 192, 1)',
//           borderWidth: 1,
//         },
//       ],
//     });
//   }, []);

  useEffect(() => {
    const labels = props.map((entry) => entry.date);
    const values = props.map((entry) => entry.amount);

    setData({
      labels: labels,
      datasets: [
        {
          label: 'Total Bet',
          data: values,
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
        },
      ],
    });
  }, [props]);
  

  return (
    <div className="container mx-auto p-4">
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4">Total Betting per Day</h2>
        <div className="h-96">
          <Bar data={data} options={{
            responsive: true,
            plugins: {
              title: {
                display: true,
                text: 'Total Bet Analysis for User Id : ' + `${props?.[0]?.userId}`,
              },
              tooltip: {
                mode: 'index',
                intersect: false,
              },
            },
            scales: {
              x: {
                title: {
                  display: true,
                  text: 'Date',
                },
              },
              y: {
                title: {
                  display: true,
                  text: 'Amount',
                },
                beginAtZero: true,
              },
            },
          }} />
        </div>
      </div>
    </div>
  );
};

export default SpendingChart;
