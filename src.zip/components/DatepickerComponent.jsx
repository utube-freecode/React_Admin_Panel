import React, { useEffect, useState } from 'react';
import DatePicker from 'react-datepicker'; // Import the react-datepicker component
import "react-datepicker/dist/react-datepicker.css"; // Import the styles

const DatepickerComponent = ({prop}) => {
  const [selectedDate, setSelectedDate] = useState(new Date());


  // useEffect
  useEffect(() => {
    prop(selectedDate);
  }, []); 
  

  // Handle date selection
  const handleDateChange = (date) => {
    setSelectedDate(date);
    prop(date)
  };

  return (
    <div className="flex flex-col items-center">
      {/* Datepicker */}
      <div className="relative w-full max-w-xs">
        {/* <label className="block text-sm font-medium text-gray-700">Select Date</label> */}
        <DatePicker
          selected={selectedDate} // Bind the selected date
          onChange={handleDateChange} // Update the date on change
          dateFormat="MMMM d, yyyy" // Format of the selected date
          className="mt-2 block w-full px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600"
          placeholderText="Select a date"
        />
      </div>

      {/* Display Selected Date */}
      {/* {selectedDate && (
        <div className="mt-4 text-lg">
          <p>You selected: {selectedDate.toLocaleDateString()}</p>
        </div>
      )} */}
    </div>
  );
};

export default DatepickerComponent;
