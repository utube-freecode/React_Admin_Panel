import React from 'react';

const WinTableAnalysis = ({ data }) => {
  // Sorting providers by total amount in descending order
  const sortedProviders = data?.sort((a, b) => b?.totalAmount - a?.totalAmount);
  
  // Calculate total amount
  const totalSum = sortedProviders?.reduce((acc, { totalAmount }) => acc + totalAmount, 0);

  return (
    <div className="container mx-auto p-4">

        <div className={`text-2xl font-bold text-center mb-4 bg-blue-500 text-white  p-4 rounded-lg shadow-md  ${totalSum > 0 ? 'bg-green-700' : totalSum < 0 ? 'bg-red-700' : 'bg-blue-500'}`}>
            Total {totalSum > 0 ? "Won" : "Loss"} Amount: {totalSum?.toFixed(2)}
        </div>

      <div className="overflow-auto max-h-[30rem] border border-gray-300 rounded-lg shadow-md">
        <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
          <thead className="top-0 bg-white text-black z-10">
            <tr className="category-row">
              <th className="p-2 border border-gray-300 text-left">Provider Name</th>
              <th className="p-2 border border-gray-300 text-left">Sub Provider</th>
              <th className="p-2 border border-gray-300 text-left">Total Won / Loss Amount</th>
              {/* <th className="p-2 border border-gray-300 text-left">Result</th> */}
            </tr>
          </thead>
          <tbody>
            {sortedProviders?.map(({ _id: { provider_name, sub_provider_name }, totalAmount }, index) => (
              <tr key={index} className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                <td className="p-2 border border-gray-200 font-bold">{provider_name}</td>
                <td className="p-2 border border-gray-200">{sub_provider_name}</td>
                <td className="p-2 border border-gray-200">
                    <span className={`inline-block px-1 py-1 text-white rounded 
                        ${totalAmount > 0 ? 'bg-green-700' : totalAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                    >
                        {totalAmount?.toFixed(2)}
                    </span>
                </td>
                {/* <td className={`p-2 border border-gray-200`}>
                    <span className={`inline-block px-1 py-1 text-white rounded 
                        ${totalAmount > 0 ? 'bg-green-700' : totalAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                    >
                        {totalAmount > 0 ? "Win" : totalAmount < 0 ? "Loss" : "Neutral"}
                    </span>
                </td> */}
              </tr>
            ))}
            {/* Total row */}
            <tr className="font-bold bg-gray-200">
              <td className="p-2 border border-gray-300">Total</td>
              <td className="p-2 border border-gray-300">{""}</td>
              <td className="p-2 border border-gray-300">
                <span className={`inline-block px-2 py-1 text-white rounded 
                    ${totalSum > 0 ? 'bg-green-700' : totalSum < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                >
                    {totalSum?.toFixed(2)}
                </span>
              </td>
              {/* <td className={`p-2 border border-gray-300`}>
                <span className={`inline-block px-2 py-1 text-white rounded 
                    ${totalSum > 0 ? 'bg-green-700' : totalSum < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                >
                    {totalSum > 0 ? "Win" : totalSum < 0 ? "Loss" : "Neutral"}
                </span>
              </td> */}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WinTableAnalysis;
