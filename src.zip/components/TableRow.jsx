import axios from 'axios';
import React, { useState } from 'react';
import { Switch } from '@headlessui/react'


const TableRow = ({ id, initialStatus, item, index }) => {

  const [isActive, setIsActive] = useState(initialStatus);
  const [loading, setLoading] = useState(false);

  const handleToggleChange = async (rowData) => {
    // Optimistically update the toggle UI
    const previousStatus = isActive;
    setIsActive(isActive === "ACTIVE" ? "BLOCKED" : "ACTIVE");
    setLoading(true);

    try {

        const response = await axios.patch(`${process.env.REACT_APP_API_URL}/panel/modifygamestatusbyid`, {
          _id : rowData?._id,
          status : isActive === "ACTIVE" ? "BLOCKED" : "ACTIVE"
        }, {
          headers : {
            "Content-Type" : "application/json"
          }
        })

        console.log(response, "response")

        setLoading(false);

        
    } catch (error) {
      // If API call fails, revert to the previous status
      console.error('API call failed:', error?.message);
      setIsActive(previousStatus);  // Revert back to the previous state
      setLoading(false);
    } 
  };

  return (
    <tr
        key={id}
        className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}
    >
        <td className="border border-gray-200">{item?.game_id || '-----'}</td>
        <td className="border border-gray-200">{item?.category || '-----'}</td>
        <td className="border border-gray-200">{item?.game_name || '-----'}</td>
        <td className="border border-gray-200">{item?.provider_name || '-----'}</td>
        <td className="border border-gray-200">{item?.sub_provider_name || '-----'}</td>
        <td className="border border-gray-200 break-words max-w-xs">{item?.game_code || '-----'}</td>
        <td className="border border-gray-200">{item?.casinoType || '-----'}</td>
        <td className="border border-gray-200">{item?.currency || '-----'}</td>
        <td className="border border-gray-300 py-2">
          <label className="inline-flex items-center cursor-pointer">
            <Switch
              checked={isActive === "ACTIVE" ? true : false}
              onChange={() => handleToggleChange(item)}
              disabled={loading} 
              className={`${isActive === "ACTIVE" ? 'bg-blue-600' : 'bg-gray-200'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-200 ease-in-out`}
            >
              <span className="sr-only">Toggle Active Status</span>
              <span
                className={`${isActive === "ACTIVE" ? 'translate-x-5' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-200 ease-in-out`}
              />
            </Switch>
          </label>
        </td>

        {/* Styles */}
        <style>{`
            /* Full Page Loader */
            .loader-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 1000; /* High z-index to overlay on top of other content */
            }

            .loader {
              border: 5px solid #f3f3f3; /* Light gray border */
              border-top: 5px solid #3498db; /* Blue color for top border */
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite; /* Spinning animation */
            }

            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }

            /* Table Loader (Inside Table) */
            .table-loader-overlay {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background-color: rgba(255, 255, 255, 0.7); /* Semi-transparent white */
              display: flex;
              align-items: center;
              justify-content: center;
              z-index: 500; /* Lower z-index than full page loader */
            }


            .table-scroll-container {
              max-height: 300px;
              overflow-y: auto;
              border: 1px solid #ddd;
              position: relative; /* Added to allow absolute positioning for table loader */
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            th, td {
              padding: 10px;
              border: 1px solid #ddd;
              text-align: left;
            }

            th {
              background-color: #f9f9f9;
            }

            .scrollable {
              word-break: break-word;
            }

            .td {
              height: 50px; /* Adjust as necessary to fit the table row */
              vertical-align: middle; /* Ensure middle alignment */
            }


          `}</style>
    </tr>
  );
};


export default TableRow
