// SingleDaySpendingChart.js
import React, { useState, useEffect } from 'react';
import { Pie } from 'react-chartjs-2'; // Import the Pie chart from react-chartjs-2
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Title } from 'chart.js'; // Import necessary components from Chart.js
import 'tailwindcss/tailwind.css'; // Ensure Tailwind is properly imported

// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend, Title);

const SingleDaySpendingChart = ({spendingData}) => {
  const [data, setData] = useState({
    labels: [],
    datasets: [
      {
        label: 'Breakdown',
        data: [],
        backgroundColor: [],
        hoverBackgroundColor: [],
      },
    ],
  });

  //console.log(spendingData, "spendingData")

    const processData = (spendingData) => {
      let labels = spendingData?.gameNames?.map((entry) => entry?.game_name) || [];
      let values = spendingData?.gameNames?.map((entry) => entry?.amount) || [];

      // Sort by amount (descending) and determine if we need to group smaller categories
      const totalAmount = values.reduce((acc, curr) => acc + curr, 0);
      const threshold = totalAmount * 0.01; // Show only categories that are more than 1% of the total
      let filteredLabels = [];
      let filteredValues = [];
      let otherValue = 0;

      labels.forEach((label, index) => {
        if (values[index] >= threshold) {
          filteredLabels.push(label);
          filteredValues.push(values[index]);
        } else {
          otherValue += values[index];
        }
      });

      // Add 'Others' category if there are small items
      if (otherValue > 0) {
        filteredLabels.push('Others');
        filteredValues.push(otherValue);
      }

      // Generate random colors for each segment (to differentiate the categories)
      const backgroundColor = filteredLabels.map(() => `rgba(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, 0.6)`);
      const hoverBackgroundColor = filteredLabels.map(() => `rgba(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, 1)`);

      setData({
        labels: filteredLabels,
        datasets: [
          {
            label: 'Spending Breakdown',
            data: filteredValues,
            backgroundColor,
            hoverBackgroundColor,
          },
        ],
      });
    };

    useEffect(() => {
      if (spendingData?.gameNames) {
        processData(spendingData);
      }
    }, [spendingData]);


  return (
    <div className="container flex flex-col items-center mx-auto p-4">
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold mb-4">{spendingData?._id?.provider_name} Breakdown</h2>
        <div className="h-96">
          <Pie
            data={data}
            options={{
              responsive: true,
              plugins: {
                title: {
                  display: true,
                  text: `${spendingData?._id?.sub_provider_name} Breakdown`,
                },
                tooltip: {
                  mode: 'index',
                  intersect: false,
                  callbacks: {
                    label: (tooltipItem) => {
                      const dataset = tooltipItem.dataset;

                      // console.log(dataset, "dataset")
                      // console.log(tooltipItem, "tooltipItem")
                  
                      const value = parseFloat(dataset.data?.[tooltipItem?.dataIndex]); // Convert the value to a number
                      const total = dataset.data.reduce((acc, value) => acc + parseFloat(value), 0); // Convert all values to numbers

                      const percentage = ((value / total) * 100).toFixed(2); // Calculate percentage
                      
                      // Return a formatted string with value and percentage
                      return `${tooltipItem.label}: ${value} (${percentage}%)`;
                    },
                  },
                  legend: {
                    position: 'top',
                  },
                },
              },
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default SingleDaySpendingChart;
