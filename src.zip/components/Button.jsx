import React from 'react'
//import { useStateContext } from '../contexts/ContextProvider'
import { toggleClick } from '../redux-store/slices/appSlice'
import { useDispatch, useSelector } from 'react-redux';

const Button = ({ color, bgColor, icon, text, borderRadius, bgHoverColor, size, width, target, ...props }) => {

  //const { handleClick, isClicked } = useStateContext();

  const dispatch = useDispatch() 

  return (
    <button
      type="button"
      onClick={() => dispatch(toggleClick(target))} // 'target' is the component you want to toggle (e.g., 'userProfile')
      style={{ backgroundColor: bgColor, color, borderRadius }}
      className={`text-${size} p-3 w-${width} hover:drop-shadow-xl hover:bg-${bgHoverColor}`}
      {...props}
    >
      {icon} {text}
    </button>
  );
};

export default Button