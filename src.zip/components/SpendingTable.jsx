import React from 'react';

const SpendingTable = ({ spendingData }) => {

  // Group data by provider and sub-provider
  const groupedData = spendingData?.reduce((acc, entry) => {
    const { provider_name, sub_provider_name } = entry?._id;

    // If the provider_name doesn't exist in the accumulator, create it
    if (!acc[provider_name]) {
      acc[provider_name] = {};
    }

    // If the sub_provider_name doesn't exist for that provider, create it
    if (!acc[provider_name][sub_provider_name]) {
      acc[provider_name][sub_provider_name] = [];
    }

    // Push the game data into the correct sub_provider
    acc[provider_name][sub_provider_name] = entry?.gameNames;

    return acc;
  }, {});

  // Calculate the total amount for each provider and sub-provider
  const summaryData = [];
  Object.keys(groupedData).forEach(providerName => {
    const providerSubData = groupedData[providerName];
    Object.keys(providerSubData).forEach(subProviderName => {
      const games = providerSubData[subProviderName];
      const totalAmount = games?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
      summaryData.push({ providerName, subProviderName, totalAmount });
    });
  });

  // Sort the summaryData by totalAmount in descending order
  const sortedSummaryData = summaryData.sort((a, b) => b.totalAmount - a.totalAmount);

  // Sorting providers by total amount in descending order
  const sortedProviders = Object.keys(groupedData)?.sort((a, b) => {
    const totalA = Object.values(groupedData[a])?.flat()?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
    const totalB = Object.values(groupedData[b])?.flat()?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
    return totalB - totalA;
  });

  // Calculate total amount
  const totalSum = sortedSummaryData?.reduce((acc, { totalAmount }) => acc + totalAmount, 0);

  return (
    <div className="container mx-auto p-4">
      
      {/* Summary Table */}
      <div className="overflow-auto max-h-[30rem] border border-gray-300 rounded-lg shadow-md">
        <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
          <thead className="top-0 bg-white text-black z-10">
            <tr className="category-row">
              <th className="p-2 border border-gray-300 text-left">Provider Name</th>
              <th className="p-2 border border-gray-300 text-left">Sub Provider</th>
              <th className="p-2 border border-gray-300 text-left">Total Bet Amount</th>
            </tr>
          </thead>
          <tbody>
            {sortedSummaryData?.map((row, index) => (
              <tr key={index} className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                <td className="p-2 border border-gray-200 font-bold">{row?.providerName}</td>
                <td className="p-2 border border-gray-200">{row?.subProviderName}</td>
                <td className="p-2 border border-gray-200">{row?.totalAmount?.toFixed(2)}</td>
              </tr>
            ))}
            {/* Total row */}
            <tr className="font-bold bg-gray-200">
              <td className="p-2 border border-gray-300">Total</td>
              <td className="p-2 border border-gray-300"></td>
              <td className="p-2 border border-gray-300">{totalSum?.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Original Spending Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
        {sortedProviders?.map((providerName) => {
          const providerSubData = groupedData[providerName];

          return (
            <div key={providerName} className="bg-white p-4 rounded-lg shadow-md">
              <h2 className="text-lg font-bold mb-2">{providerName}</h2>
              <div className="overflow-auto max-h-[20rem] border border-gray-300 rounded-lg shadow-md">
                <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
                  <thead className="top-0 bg-white text-black z-10">
                    <tr className="category-row">
                      <th className="p-1 border border-gray-300 text-left cursor-pointer">Sub Provider</th>
                      <th className="p-1 border border-gray-300 text-left cursor-pointer">Game Name</th>
                      <th className="p-1 border border-gray-300 text-left cursor-pointer">Amount</th>
                      <th className="p-1 border border-gray-300 text-left cursor-pointer">%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.keys(providerSubData)?.map((subProviderName, index) => {
                      let games = providerSubData[subProviderName];
                      const totalAmount = games?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);

                      // Sorting games by amount in descending order
                      games = games?.sort((a, b) => parseFloat(b?.amount) - parseFloat(a?.amount));

                      return (
                        <React.Fragment key={index}>
                          <tr className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                            <td rowSpan={games.length + 1} className="font-bold px-2 py-1 border">
                              {subProviderName}
                            </td>
                          </tr>
                          {games?.map((game, gameIndex) => {
                            const gameAmount = parseFloat(game?.amount);
                            const percentage = totalAmount === 0 ? 0 : ((gameAmount / totalAmount) * 100)?.toFixed(2);

                            return (
                              <tr key={gameIndex} className={`border-b ${gameIndex % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                                <td className="p-1 border border-gray-200">{game?.game_name}</td>
                                <td className="p-1 border border-gray-200">{gameAmount}</td>
                                <td className="p-1 border border-gray-200">{percentage}%</td>
                              </tr>
                            );
                          })}
                          <tr className="font-bold total-row">
                            <td colSpan="2" className="p-1 border border-gray-200">Total</td>
                            <td className="p-1 border border-gray-200">{totalAmount?.toFixed(2)}</td>
                            <td colSpan="2" className="p-1 border border-gray-200">100%</td>
                          </tr>
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SpendingTable;
