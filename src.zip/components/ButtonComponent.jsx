
export const ButtonComponent = ({ children, className, ...props }) => (
    <button
      className={`px-4 py-2 rounded-lg bg-blue-500 text-white font-medium hover:bg-blue-600 focus:ring-2 focus:ring-blue-300 ${className}`}
      {...props}
    >
      {children}
    </button>
);
  