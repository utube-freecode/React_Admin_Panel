
import { useState } from "react";

// Wrapper for the select component
export const Select = ({ children, className }) => (
  <div className={`relative ${className}`}>{children}</div>
);

// Button to trigger dropdown visibility
export const SelectTrigger = ({ value, onClick, className, placeholder }) => (
  <button
    className={`w-full px-4 py-2 border rounded-lg bg-gray-100 text-left hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300 ${className}`}
    onClick={onClick}
  >
    {value || placeholder || "Select..."}
  </button>
);

// Dropdown content
export const SelectContent = ({ isOpen, children, className }) => (
  <div
    className={`absolute z-10 mt-2 w-full bg-white border rounded-lg shadow-lg ${
      isOpen ? "block" : "hidden"
    } ${className}`}
  >
    {children}
  </div>
);

// Individual items in the dropdown
export const SelectItem = ({ value, onSelect, className }) => (
  <div
    className={`px-4 py-2 hover:bg-gray-100 cursor-pointer ${className}`}
    onClick={() => onSelect(value)}
  >
    {value}
  </div>
);
