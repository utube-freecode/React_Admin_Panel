import React from "react";

const SkeletonLoader = ({ type = "table", rows = 5, columns = 3, contentBlocks = 3 }) => {
  return (
    <div className="animate-pulse">
      {type === "table" ? (
        // Skeleton Table Loader
        <div className="overflow-auto max-h-[30rem] border border-gray-300 rounded-lg shadow-md">
          <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
            <thead className="top-0 bg-white text-black z-10">
              <tr>
                {[...Array(columns)].map((_, colIndex) => (
                  <th key={colIndex} className="p-2 border border-gray-300 bg-gray-200">
                    <div className="h-4 w-32 bg-gray-300 rounded"></div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: rows }).map((_, rowIndex) => (
                <tr key={rowIndex} className="border-b">
                  {[...Array(columns)].map((_, colIndex) => (
                    <td key={colIndex} className="p-2 border border-gray-200">
                      <div className="h-4 w-24 bg-gray-300 rounded"></div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        // Skeleton Content Loader
        <div className="flex flex-col space-y-4">
          {Array.from({ length: contentBlocks }).map((_, index) => (
            <div key={index} className="p-4 border border-gray-200 rounded-lg shadow-md bg-white">
              {/* Title */}
              <div className="h-6 w-48 bg-gray-300 rounded mb-2"></div>
              {/* Paragraph */}
              <div className="h-4 w-full bg-gray-300 rounded mb-1"></div>
              <div className="h-4 w-5/6 bg-gray-300 rounded mb-1"></div>
              <div className="h-4 w-2/3 bg-gray-300 rounded"></div>
              {/* Button */}
              <div className="mt-4 h-10 w-24 bg-gray-300 rounded"></div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes shimmer {
            0% { background-position: -200px 0; }
            100% { background-position: 200px 0; }
        }

        .animate-shimmer {
            background: linear-gradient(to right, #e0e0e0 8%, #f0f0f0 18%, #e0e0e0 33%);
            background-size: 1000px 100%;
            animation: shimmer 1.5s infinite linear;
        }
      `}</style>


    </div>
  );
};

export default SkeletonLoader;
