import React from 'react';

const WinTable = ({ data }) => {

  //console.log(data, "data")

  const groupedData = data?.reduce((acc, entry) => {
    const { provider_name, sub_provider_name } = entry?._id;

     // If the provider_name doesn't exist in the accumulator, create it
    if (!acc[provider_name]) {
      acc[provider_name] = {};
    }

    // If the sub_provider_name doesn't exist for that provider, create it
    if (!acc[provider_name][sub_provider_name]) {
      acc[provider_name][sub_provider_name] = [];
    }

     // Push the game data into the correct sub_provider
    acc[provider_name][sub_provider_name] = entry?.gameNames;

    return acc;
  }, {});

    //console.log(groupedData, "groupedData")

    // Sorting providers by total amount in descending order
    const sortedProviders = Object.keys(groupedData)?.sort((a, b) => {
      const totalA = Object.values(groupedData[a])?.flat()?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
      const totalB = Object.values(groupedData[b])?.flat()?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
      return totalB - totalA;
    });


    return (
        <div className="container mx-auto p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sortedProviders?.map((providerName) => {
              const providerSubData = groupedData[providerName];
    
              return (
                <div key={providerName} className="bg-white text-black p-4 rounded-lg shadow-md">
                  <h2 className="text-lg font-bold mb-2 text-black">{providerName}</h2>
                  <div className="overflow-auto max-h-[20rem] border border-gray-300 rounded-lg shadow-md">
                    <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
                      <thead className="top-0 bg-white text-black z-10">
                        <tr className="category-row">
                          <th className="p-1 border border-gray-300 text-left cursor-pointer">Sub Provider</th>
                          <th className="p-1 border border-gray-300 text-left cursor-pointer">Game Name</th>
                          <th className="p-1 border border-gray-300 text-left cursor-pointer">Amount</th>
                          {/* <th className="p-1 border border-gray-300 text-left cursor-pointer">Result</th> */}
                          {/* <th className="p-1 border border-gray-300 text-left cursor-pointer">%</th> */}
                        </tr>
                      </thead>
                      <tbody>
                        {Object.keys(providerSubData)?.map((subProviderName, index) => {
                          let games = providerSubData[subProviderName];
                          const totalAmount = games?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
    
                          // Sorting games by amount in descending order
                          games = games?.sort((a, b) => parseFloat(b?.amount) - parseFloat(a?.amount));
    
                          return (
                            <React.Fragment key={index}>
                              <tr className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                                <td rowSpan={games.length + 1} className="font-bold px-2 py-1 border">
                                  {subProviderName}
                                </td>
                              </tr>
                              {games?.map((game, gameIndex) => {
                                const gameAmount = parseFloat(game?.amount);
                                const percentage = totalAmount === 0 ? 0 : ((gameAmount / totalAmount) * 100)?.toFixed(2);
    
                                // Determine result based on the amount value
                                let result;
                                let resultClass = '';
                                if (gameAmount > 0) {
                                  result = 'Win';
                                  resultClass = 'text-green-500'; // Green for win
                                } else if (gameAmount < 0) {
                                  result = 'Loss';
                                  resultClass = 'text-red-500'; // Red for loss
                                } else {
                                  result = 'Neutral';
                                  resultClass = 'text-gray-500'; // Gray for neutral
                                }
    
                                return (
                                  <tr key={gameIndex} className={`border-b ${gameIndex % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                                    <td className="p-1 border border-gray-200">{game.game_name}</td>
                                    <td className="p-1 border border-gray-200">
                                      <span className={`inline-block px-1 py-1 text-white rounded 
                                            ${gameAmount > 0 ? 'bg-green-700' : gameAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                                        >
                                            {gameAmount?.toFixed(2)}
                                        </span>
                                    </td>
                                    {/* <td className={`p-1 border border-gray-200`}>
                                        <span className={`inline-block px-1 py-1 text-white rounded 
                                            ${gameAmount > 0 ? 'bg-green-700' : gameAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                                        >
                                            {gameAmount > 0 ? "Win" : gameAmount < 0 ? "Loss" : "Neutral"}
                                        </span>
                                    </td> */}
                                    {/* <td className="p-1 border border-gray-200">{percentage}%</td> */}
                                  </tr>
                                );
                              })}
                              <tr className="font-bold total-row">
                                <td colSpan="2" className="p-1 border border-gray-200">Total</td>
                                <td className="p-1 border border-gray-200">
                                  <span className={`inline-block px-1 py-1 text-white rounded 
                                        ${totalAmount > 0 ? 'bg-green-700' : totalAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                                    >
                                        {totalAmount?.toFixed(2)}
                                    </span>
                                </td>
                                {/* <td className={`p-1 border border-gray-200`}>
                                    <span className={`inline-block px-1 py-1 text-white rounded 
                                        ${totalAmount > 0 ? 'bg-green-700' : totalAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                                    >
                                        {totalAmount > 0 ? "Win" : totalAmount < 0 ? "Loss" : "Neutral"}
                                    </span>
                                </td> */}
                                {/* <td className="p-1 border border-gray-200">100%</td> */}
                              </tr>
                            </React.Fragment>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
};

export default WinTable;