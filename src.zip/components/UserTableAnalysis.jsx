import React from 'react';

const UserTableAnalysis = ({ data }) => {

  // Group data by userName and userId
  const groupedData = data?.reduce((acc, entry) => {
    const { userName, userId } = entry?._id;

    // If the userName doesn't exist in the accumulator, create it
    if (!acc[userName]) {
      acc[userName] = {};
    }

    // If the userId doesn't exist for that userName, create it
    if (!acc[userName][userId]) {
      acc[userName][userId] = [];
    }

    // Push the game data into the correct userId
    acc[userName][userId] = entry?.gameNames;

    return acc;
  }, {});

  // Calculate total amounts by userName
  const totalAmountPerUser = Object.keys(groupedData)?.map((userName) => {
    const userGames = groupedData[userName];
    const totalAmount = Object.values(userGames)?.flat()?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);
    return { userName, totalAmount };
  });

  // Sorting users by total amount in descending order
  const sortedUsernamesByTotalAmount = totalAmountPerUser?.sort((a, b) => b?.totalAmount - a?.totalAmount);


  return (
    <div className="container mx-auto p-4">
      {/* First Table: UserName and Total Amount in descending order */}
      <div className="bg-white text-black p-4 rounded-lg shadow-md mb-4">
        <h2 className="text-lg font-bold mb-2 text-black">Total Amount Won by User</h2>
        <div className="overflow-auto max-h-[20rem] border border-gray-300 rounded-lg shadow-md">
          <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
            <thead className="top-0 bg-white text-black z-10">
              <tr className="category-row">
                <th className="p-1 border border-gray-300 text-left">User Name</th>
                <th className="p-1 border border-gray-300 text-left">Total Won / Loss Amount</th>
              </tr>
            </thead>
            <tbody>
              {sortedUsernamesByTotalAmount?.map((user, index) => (
                <tr key={index} className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                  <td className="p-1 border border-gray-200">{user?.userName}</td>
                  <td className="p-1 border border-gray-200">
                    <span className={`inline-block px-1 py-1 text-white rounded 
                          ${user?.totalAmount > 0 ? 'bg-green-700' : user?.totalAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                    >
                      {user?.totalAmount?.toFixed(2)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Second Table: Detailed game data sorted by total amount per user */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedUsernamesByTotalAmount?.map((user, userIndex) => {
          const providerSubData = groupedData[user?.userName];

          return (
            <div key={userIndex} className="bg-white text-black p-4 rounded-lg shadow-md">
              <h2 className="text-lg font-bold mb-2 text-black">{user?.userName}</h2>
              <div className="overflow-auto max-h-[20rem] border border-gray-300 rounded-lg shadow-md">
                <table className="min-w-full table-auto border-collapse border-spacing-0 bg-white text-sm">
                  <thead className="top-0 bg-white text-black z-10">
                    <tr className="category-row">
                      <th className="p-1 border border-gray-300 text-left cursor-pointer">Game Name</th>
                      <th className="p-1 border border-gray-300 text-left cursor-pointer">Won / Loss Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.keys(providerSubData)?.map((userId, index) => {
                      let games = providerSubData[userId];
                      const totalAmount = games?.reduce((acc, game) => acc + parseFloat(game?.amount), 0);

                      // Sorting games by amount in descending order
                      games = games?.sort((a, b) => parseFloat(b?.amount) - parseFloat(a?.amount));

                      return (
                        <React.Fragment key={index}>
                          <tr className={`border-b ${index % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                          </tr>
                          {games?.map((game, gameIndex) => {
                            const gameAmount = parseFloat(game?.amount);
                            const percentage = totalAmount === 0 ? 0 : ((gameAmount / totalAmount) * 100)?.toFixed(2);

                            return (
                              <tr key={gameIndex} className={`border-b ${gameIndex % 2 === 0 ? 'bg-gray-50' : 'bg-gray-100'} hover:bg-blue-100`}>
                                <td className="p-1 border border-gray-200">{game?.game_name}</td>
                                <td className="p-1 border border-gray-200">
                                  <span className={`inline-block px-1 py-1 text-white rounded 
                                        ${gameAmount > 0 ? 'bg-green-700' : gameAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                                    >
                                      {gameAmount?.toFixed(2)}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                          <tr className="font-bold total-row">
                            <td className="p-1 border border-gray-200">Total</td>
                            <td className="p-1 border border-gray-200">
                              <span className={`inline-block px-1 py-1 text-white rounded 
                                    ${totalAmount > 0 ? 'bg-green-700' : totalAmount < 0 ? 'bg-red-700' : 'bg-gray-500'}`}
                                >
                                {totalAmount?.toFixed(2)}
                              </span>
                            </td>
                          </tr>
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default UserTableAnalysis;
